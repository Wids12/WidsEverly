// ============================================================
// 👥 GROUP CHAT API + WEBSOCKET PATCH
// Paste this block into index_chat_coppyjjj.js BEFORE server.listen(...)
// ============================================================

const GROUPS_FILE = path.join(__dirname, 'groups.json');

function ensureGroupsFile() {
  if (!fs.existsSync(GROUPS_FILE)) {
    fs.writeFileSync(GROUPS_FILE, '[]', 'utf8');
  }
}

function loadGroups() {
  ensureGroupsFile();
  try {
    const raw = fs.readFileSync(GROUPS_FILE, 'utf8').trim();
    if (!raw) return [];
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch (e) {
    console.error('[GROUP] Gagal membaca groups.json:', e.message);
    return [];
  }
}

function saveGroups(groups) {
  const tmp = `${GROUPS_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(groups, null, 2), 'utf8');
  fs.renameSync(tmp, GROUPS_FILE);
}

function groupId() {
  return `group_${crypto.randomUUID()}`;
}

function groupMessageId() {
  return `gm_${crypto.randomUUID()}`;
}

function getAuthUsername(req) {
  const key = String(req.query?.key || req.body?.key || req.headers['x-session-key'] || '').trim();
  if (!key) return null;
  return getUserByKey(key);
}

function groupSafeProfile(username) {
  return getChatUserProfile(username) || { username, name: username, role: 'member' };
}

function findGroup(id) {
  return loadGroups().find(g => String(g.id) === String(id));
}

function isGroupMember(group, username) {
  const me = String(username || '').toLowerCase();
  return Array.isArray(group?.members) && group.members.some(m => String(m.username).toLowerCase() === me);
}

function isGroupAdmin(group, username) {
  const me = String(username || '').toLowerCase();
  return Array.isArray(group?.admins) && group.admins.some(u => String(u).toLowerCase() === me);
}

function cleanGroup(group) {
  if (!group) return null;
  return {
    id: group.id,
    name: group.name,
    description: group.description || '',
    avatarUrl: group.avatarUrl || null,
    creator: group.creator,
    admins: group.admins || [],
    members: group.members || [],
    permissions: group.permissions || {
      editSettings: true,
      sendMessages: true,
      addMembers: true,
      inviteLink: false,
      approveMembers: false
    },
    createdAt: group.createdAt,
    updatedAt: group.updatedAt
  };
}

function broadcastGroup(group, payload) {
  if (!group || !Array.isArray(group.members)) return;
  const data = JSON.stringify(payload);
  for (const member of group.members) {
    const client = wsClients[member.username];
    if (client && client.readyState === WebSocket.OPEN) {
      try { client.send(data); } catch (_) {}
    }
  }
}

ensureGroupsFile();

// -----------------------------
// CREATE GROUP
// POST /api/groups
// body: { key, name, description, memberUsernames: [], avatarUrl?, permissions? }
// Maksimal 10 member yang dipilih dari halaman "Pilih kontak".
// Creator otomatis menjadi admin dan anggota, sehingga total dapat 11 akun.
// -----------------------------
app.post('/api/groups', (req, res) => {
  try {
    const creator = getAuthUsername(req);
    if (!creator) return res.status(401).json({ error: 'Invalid session key' });

    const name = sanitize(req.body?.name || '').slice(0, 100);
    const description = sanitize(req.body?.description || '').slice(0, 500);
    const selected = Array.isArray(req.body?.memberUsernames) ? req.body.memberUsernames : [];

    if (!name) return res.status(400).json({ error: 'Nama grup wajib diisi' });
    if (selected.length < 1) return res.status(400).json({ error: 'Pilih minimal 1 anggota' });
    if (selected.length > 10) return res.status(400).json({ error: 'Maksimal 10 anggota sekali tambah' });

    const unique = [...new Set(selected.map(normalizeChatUsername).filter(Boolean))]
      .filter(u => u.toLowerCase() !== creator.toLowerCase());

    if (unique.length < 1) return res.status(400).json({ error: 'Anggota grup tidak valid' });
    if (unique.length > 10) return res.status(400).json({ error: 'Maksimal 10 anggota sekali tambah' });

    const profiles = unique.map(getChatUserProfile);
    const missing = unique.filter((u, i) => !profiles[i]);
    if (missing.length) {
      return res.status(400).json({ error: 'Ada user yang tidak ditemukan', missing });
    }

    const now = new Date().toISOString();
    const creatorProfile = groupSafeProfile(creator);
    const members = [
      { username: creatorProfile.username, name: creatorProfile.name, role: 'admin', joinedAt: now },
      ...profiles.map(p => ({ username: p.username, name: p.name, role: 'member', joinedAt: now }))
    ];

    const group = {
      id: groupId(),
      name,
      description,
      avatarUrl: req.body?.avatarUrl || null,
      creator: creatorProfile.username,
      admins: [creatorProfile.username],
      members,
      permissions: {
        editSettings: req.body?.permissions?.editSettings !== false,
        sendMessages: req.body?.permissions?.sendMessages !== false,
        addMembers: req.body?.permissions?.addMembers !== false,
        inviteLink: req.body?.permissions?.inviteLink === true,
        approveMembers: req.body?.permissions?.approveMembers === true
      },
      createdAt: now,
      updatedAt: now
    };

    const groups = loadGroups();
    groups.push(group);
    saveGroups(groups);

    broadcastGroup(group, { type: 'groupCreated', group: cleanGroup(group) });
    return res.status(201).json({ success: true, group: cleanGroup(group) });
  } catch (e) {
    console.error('[GROUP CREATE]', e);
    return res.status(500).json({ error: 'Gagal membuat grup' });
  }
});

// GET /api/groups?key=...
app.get('/api/groups', (req, res) => {
  const username = getAuthUsername(req);
  if (!username) return res.status(401).json({ error: 'Invalid session key' });

  const groups = loadGroups()
    .filter(g => isGroupMember(g, username))
    .map(cleanGroup);

  return res.json({ success: true, groups });
});

// GET /api/groups/:id
app.get('/api/groups/:id', (req, res) => {
  const username = getAuthUsername(req);
  if (!username) return res.status(401).json({ error: 'Invalid session key' });

  const group = findGroup(req.params.id);
  if (!group) return res.status(404).json({ error: 'Grup tidak ditemukan' });
  if (!isGroupMember(group, username)) return res.status(403).json({ error: 'Bukan anggota grup' });

  return res.json({ success: true, group: cleanGroup(group) });
});

// PATCH /api/groups/:id
// body: { key, name?, description?, avatarUrl? }
app.patch('/api/groups/:id', (req, res) => {
  const username = getAuthUsername(req);
  if (!username) return res.status(401).json({ error: 'Invalid session key' });

  const groups = loadGroups();
  const index = groups.findIndex(g => String(g.id) === String(req.params.id));
  if (index === -1) return res.status(404).json({ error: 'Grup tidak ditemukan' });

  const group = groups[index];
  if (!isGroupMember(group, username)) return res.status(403).json({ error: 'Bukan anggota grup' });
  if (!isGroupAdmin(group, username)) return res.status(403).json({ error: 'Hanya admin yang dapat mengubah pengaturan grup' });
  if (group.permissions?.editSettings === false) return res.status(403).json({ error: 'Edit pengaturan grup dinonaktifkan' });

  if (req.body?.name !== undefined) {
    const name = sanitize(req.body.name).slice(0, 100);
    if (!name) return res.status(400).json({ error: 'Nama grup tidak boleh kosong' });
    group.name = name;
  }
  if (req.body?.description !== undefined) group.description = sanitize(req.body.description).slice(0, 500);
  if (req.body?.avatarUrl !== undefined) group.avatarUrl = req.body.avatarUrl || null;
  group.updatedAt = new Date().toISOString();

  saveGroups(groups);
  broadcastGroup(group, { type: 'groupUpdated', group: cleanGroup(group) });
  return res.json({ success: true, group: cleanGroup(group) });
});

// POST /api/groups/:id/members
// body: { key, usernames: [] }
// Maksimal 10 member dalam satu request.
app.post('/api/groups/:id/members', (req, res) => {
  const username = getAuthUsername(req);
  if (!username) return res.status(401).json({ error: 'Invalid session key' });

  const groups = loadGroups();
  const index = groups.findIndex(g => String(g.id) === String(req.params.id));
  if (index === -1) return res.status(404).json({ error: 'Grup tidak ditemukan' });

  const group = groups[index];
  if (!isGroupMember(group, username)) return res.status(403).json({ error: 'Bukan anggota grup' });
  if (!isGroupAdmin(group, username)) return res.status(403).json({ error: 'Hanya admin yang dapat menambah anggota' });
  if (group.permissions?.addMembers === false) return res.status(403).json({ error: 'Penambahan anggota dinonaktifkan' });

  const list = Array.isArray(req.body?.usernames) ? req.body.usernames : [];
  if (!list.length) return res.status(400).json({ error: 'Pilih anggota terlebih dahulu' });
  if (list.length > 10) return res.status(400).json({ error: 'Maksimal 10 anggota sekali tambah' });

  const current = new Set(group.members.map(m => m.username.toLowerCase()));
  const unique = [...new Set(list.map(normalizeChatUsername).filter(Boolean))]
    .filter(u => !current.has(u.toLowerCase()));

  if (unique.length > 10) return res.status(400).json({ error: 'Maksimal 10 anggota sekali tambah' });

  const profiles = unique.map(getChatUserProfile);
  const missing = unique.filter((u, i) => !profiles[i]);
  if (missing.length) return res.status(400).json({ error: 'Ada user yang tidak ditemukan', missing });

  const now = new Date().toISOString();
  for (const p of profiles) {
    group.members.push({ username: p.username, name: p.name, role: 'member', joinedAt: now });
  }
  group.updatedAt = now;
  saveGroups(groups);

  broadcastGroup(group, { type: 'groupUpdated', group: cleanGroup(group) });
  return res.json({ success: true, added: profiles.map(p => p.username), group: cleanGroup(group) });
});

// DELETE /api/groups/:id/members/:username?key=...
app.delete('/api/groups/:id/members/:username', (req, res) => {
  const username = getAuthUsername(req);
  if (!username) return res.status(401).json({ error: 'Invalid session key' });

  const groups = loadGroups();
  const index = groups.findIndex(g => String(g.id) === String(req.params.id));
  if (index === -1) return res.status(404).json({ error: 'Grup tidak ditemukan' });

  const group = groups[index];
  const target = decodeURIComponent(req.params.username);
  if (!isGroupAdmin(group, username)) return res.status(403).json({ error: 'Hanya admin yang dapat menghapus anggota' });
  if (!isGroupMember(group, target)) return res.status(404).json({ error: 'Anggota tidak ditemukan' });
  if (String(target).toLowerCase() === String(group.creator).toLowerCase()) return res.status(400).json({ error: 'Pembuat grup tidak dapat dihapus' });

  group.members = group.members.filter(m => m.username.toLowerCase() !== target.toLowerCase());
  group.admins = group.admins.filter(a => a.toLowerCase() !== target.toLowerCase());
  group.updatedAt = new Date().toISOString();
  saveGroups(groups);

  broadcastGroup(group, { type: 'groupUpdated', group: cleanGroup(group) });
  const targetWs = wsClients[target];
  if (targetWs && targetWs.readyState === WebSocket.OPEN) {
    try { targetWs.send(JSON.stringify({ type: 'groupRemoved', groupId: group.id })); } catch (_) {}
  }

  return res.json({ success: true, group: cleanGroup(group) });
});

// PATCH /api/groups/:id/permissions
// body: { key, editSettings?, sendMessages?, addMembers?, inviteLink?, approveMembers? }
app.patch('/api/groups/:id/permissions', (req, res) => {
  const username = getAuthUsername(req);
  if (!username) return res.status(401).json({ error: 'Invalid session key' });

  const groups = loadGroups();
  const index = groups.findIndex(g => String(g.id) === String(req.params.id));
  if (index === -1) return res.status(404).json({ error: 'Grup tidak ditemukan' });

  const group = groups[index];
  if (!isGroupAdmin(group, username)) return res.status(403).json({ error: 'Hanya admin yang dapat mengubah izin grup' });

  const keys = ['editSettings', 'sendMessages', 'addMembers', 'inviteLink', 'approveMembers'];
  for (const k of keys) {
    if (typeof req.body?.[k] === 'boolean') group.permissions[k] = req.body[k];
  }
  group.updatedAt = new Date().toISOString();
  saveGroups(groups);
  broadcastGroup(group, { type: 'groupUpdated', group: cleanGroup(group) });

  return res.json({ success: true, permissions: group.permissions, group: cleanGroup(group) });
});

// GET /api/groups/:id/messages?key=...&limit=100&before=...
app.get('/api/groups/:id/messages', (req, res) => {
  const username = getAuthUsername(req);
  if (!username) return res.status(401).json({ error: 'Invalid session key' });

  const group = findGroup(req.params.id);
  if (!group) return res.status(404).json({ error: 'Grup tidak ditemukan' });
  if (!isGroupMember(group, username)) return res.status(403).json({ error: 'Bukan anggota grup' });

  const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 200);
  let messages = groupMessages.filter(m => m.groupId === group.id && !m.deletedForEveryone);
  messages = messages.slice(-limit);
  return res.json({ success: true, groupId: group.id, messages });
});

// POST /api/groups/:id/messages
// body: { key, message, mediaUrl?, mediaType?, fileName?, fileSize?, mimeType? }
app.post('/api/groups/:id/messages', (req, res) => {
  const username = getAuthUsername(req);
  if (!username) return res.status(401).json({ error: 'Invalid session key' });

  const group = findGroup(req.params.id);
  if (!group) return res.status(404).json({ error: 'Grup tidak ditemukan' });
  if (!isGroupMember(group, username)) return res.status(403).json({ error: 'Bukan anggota grup' });
  if (group.permissions?.sendMessages === false && !isGroupAdmin(group, username)) {
    return res.status(403).json({ error: 'Pengiriman pesan baru dinonaktifkan' });
  }

  const message = sanitize(req.body?.message || '');
  const mediaUrl = req.body?.mediaUrl || null;
  if (!message && !mediaUrl) return res.status(400).json({ error: 'Pesan kosong' });

  const profile = groupSafeProfile(username);
  const item = {
    id: groupMessageId(),
    groupId: group.id,
    from: profile.username,
    senderName: profile.name,
    message,
    messageType: req.body?.mediaType || 'text',
    mediaUrl,
    fileName: req.body?.fileName || null,
    fileSize: req.body?.fileSize || null,
    mimeType: req.body?.mimeType || null,
    createdAt: new Date().toISOString(),
    status: 'sent'
  };

  groupMessages.push(item);
  saveGroupMessages();
  broadcastGroup(group, { type: 'groupMessage', message: item });
  return res.status(201).json({ success: true, message: item });
});

// POST /api/groups/:id/admins/:username
app.post('/api/groups/:id/admins/:username', (req, res) => {
  const username = getAuthUsername(req);
  if (!username) return res.status(401).json({ error: 'Invalid session key' });

  const groups = loadGroups();
  const index = groups.findIndex(g => String(g.id) === String(req.params.id));
  if (index === -1) return res.status(404).json({ error: 'Grup tidak ditemukan' });
  const group = groups[index];
  if (!isGroupAdmin(group, username)) return res.status(403).json({ error: 'Hanya admin' });

  const target = decodeURIComponent(req.params.username);
  if (!isGroupMember(group, target)) return res.status(404).json({ error: 'Anggota tidak ditemukan' });
  if (!group.admins.some(a => a.toLowerCase() === target.toLowerCase())) group.admins.push(target);
  const member = group.members.find(m => m.username.toLowerCase() === target.toLowerCase());
  if (member) member.role = 'admin';
  group.updatedAt = new Date().toISOString();
  saveGroups(groups);
  broadcastGroup(group, { type: 'groupUpdated', group: cleanGroup(group) });
  return res.json({ success: true, group: cleanGroup(group) });
});

// -----------------------------
// Group message storage
// -----------------------------
const GROUP_MESSAGES_FILE = path.join(__dirname, 'group_messages.json');
function loadGroupMessages() {
  try {
    if (!fs.existsSync(GROUP_MESSAGES_FILE)) {
      fs.writeFileSync(GROUP_MESSAGES_FILE, '[]', 'utf8');
      return [];
    }
    const raw = fs.readFileSync(GROUP_MESSAGES_FILE, 'utf8').trim();
    if (!raw) return [];
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch (e) {
    console.error('[GROUP MSG] Gagal membaca:', e.message);
    return [];
  }
}
function saveGroupMessages() {
  const tmp = `${GROUP_MESSAGES_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(groupMessages, null, 2), 'utf8');
  fs.renameSync(tmp, GROUP_MESSAGES_FILE);
}
let groupMessages = loadGroupMessages();

// ============================================================
// END GROUP CHAT API + WEBSOCKET PATCH
// ============================================================
